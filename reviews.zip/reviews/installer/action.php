<?php
@session_start();
if($_REQUEST['action'] == "db_info")
{
    $hostNameP = trim($_REQUEST['hostname']);
    $userNameP = trim($_REQUEST['username']);
    $passWordP = trim($_REQUEST['password']);
    $databaseNameP = trim($_REQUEST['database_name']);
    $Conn_db = mysqli_connect($hostNameP, $userNameP, $passWordP, $databaseNameP);
    if (mysqli_connect_errno()){
        //echo "Failed to connect to MySQL: " . mysqli_connect_error();
        die("2"); // Could not connect to Database
    }
    /*if(!$Conn_db)
    {
        die("2"); // Could not connect to Database
    }
    */
    $db_selected = mysqli_select_db($Conn_db, $databaseNameP);
    if(!$db_selected)
    {
        die("3"); // Database doesn't exists
    }
    mysqli_close($Conn_db);
    
    $stringDB = '<?php @session_start();';
    $stringDB .= '$hostname = "'.$hostNameP.'";';
    $stringDB .= '$username = "'.$userNameP.'";';
    $stringDB .= '$password = "'.$passWordP.'";';
    $stringDB .= '$database = "'.$databaseNameP.'";';
    $stringDB .= '$con = mysqli_connect($hostname,$username,$password,$database);';
    $stringDB .= '$conn = $con; ?>';
    
    updateDatabaseFile($stringDB);
    
    include_once('../database.php');
    $file = @file_get_contents("reviews.sql");
    if(strlen($file)>10)
    $databaseQuery = sprintf($file);
    $databaseQuery = $file;
    $queryArray = array();
    $queryArray = explode(';',$databaseQuery);
    for($i=0;$i<count($queryArray);$i++)
    {
        if(trim($queryArray[$i])!='')
    	mysqli_query($con,$queryArray[$i]);
    }
    die("1");
}
else if($_REQUEST['action'] == "twilio")
{
        
}
else if($_REQUEST['action'] == "personal_info")
{
    include_once("../database.php");
    
    $sql_twi = "select id from user";
    $exe_twi = mysqli_query($con,$sql_twi);
    $count = mysqli_num_rows($exe_twi);
    if($count == 0)
    {    
         $sql222 = "insert into user 
                (name, email, password, phone, type) 
                    values 
                ('".$_REQUEST['name']."','".$_REQUEST['email']."','".$_REQUEST['password']."','".$_REQUEST['phone']."','1')";
        $exe222 = mysqli_query($con,$sql222)  or die(mysqli_error($con));
        if(!$exe222)
        {
            die("2");
        }
        
    
        $sql = "insert into settings 
                                            (version) 
                                                values 
                                            ('1.1')";
        $sql_2 = mysqli_query($con,$sql)  or die(mysqli_error($con));
        if(!$sql_2)
        {
            die("3");
        }
    }
    echo "1";
}
else if($_REQUEST['action'] == "app_info")
{
    
}
else if($_REQUEST['action'] == "check_db")
{
    $hostName = $_POST['host_name'];
    $userName = $_POST['user_name'];
    $password = $_POST['password'];
    $databaseName = $_POST['database_name'];
    
    
    $Conn_db = mysqli_connect($hostName, $userName, $password, $databaseName);
    if (mysqli_connect_errno()){
        //echo "Failed to connect to MySQL: " . mysqli_connect_error();
        die("0"); // Could not connect to Database
    }

    $db_selected = mysqli_select_db($Conn_db, $databaseName);
    if(!$db_selected)
    {
        die("0"); // Database doesn't exists
    }
    echo 1;
}

//// Functions 
function updateDatabaseFile($data)
{
    $myFile = "../database.php";
    $fh = fopen($myFile, 'w') or die("can't open file");
    fwrite($fh, $data);
    fclose($fh);
}

function DBin($string)
{
	$a = html_entity_decode($string);
	return trim(htmlspecialchars($a,ENT_QUOTES));
}

function geturls()
{
    $serverName = $_SERVER['SERVER_NAME'];
    $filePath = $_SERVER['REQUEST_URI'];
    $withInstall = substr($filePath,0,strrpos($filePath,'/'));
    $serverPath = $_SERVER['SERVER_NAME'].substr($withInstall,0,strrpos($withInstall,'/')+1);
    $applicationPath = $serverPath;
    if(strpos($applicationPath,'http://www.')===false)
    {
    	if(strpos($applicationPath,'www.')===false)
    		$applicationPath = 'www.'.$applicationPath;
    	if(strpos($applicationPath,'http://')===false)
    		$applicationPath = 'http://'.$applicationPath;
    	$callURL			=	$applicationPath.'calls_controlling.php';
    	$smsURL				=	$applicationPath.'sms_controlling.php';
    }
    else
    {
    	$callURL			=	$applicationPath.'/calls_controlling.php';
    	$smsURL				=	$applicationPath.'/sms_controlling.php';
    }
    $data['smsurl']     = $smsURL;
    $data['callurl']    = $callURL;
    return $data;
}
?>