-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 10, 2019 at 07:13 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 7.2.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `reviews`
--

-- --------------------------------------------------------

--
-- Table structure for table `autoresponders`
--

CREATE TABLE `autoresponders` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `reply_msg` text,
  `personal_msg` text,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `campaigns`
--

CREATE TABLE `campaigns` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `fb_page` text,
  `page_name` varchar(255) DEFAULT NULL,
  `page_token` text,
  `google_business` text,
  `place_id` varchar(50) DEFAULT NULL,
  `yelp_business_id` varchar(255) DEFAULT NULL,
  `is_facebook` int(11) NOT NULL DEFAULT '0',
  `is_google` int(11) NOT NULL DEFAULT '0',
  `is_yelp` int(11) NOT NULL DEFAULT '0',
  `is_custom` int(11) NOT NULL DEFAULT '0',
  `style` varchar(10) DEFAULT NULL,
  `name_color` varchar(10) DEFAULT NULL,
  `rating_color` varchar(10) DEFAULT NULL,
  `date_color` varchar(10) DEFAULT NULL,
  `review_color` varchar(10) DEFAULT NULL,
  `widget_bg_color` varchar(10) DEFAULT NULL,
  `widget_box_shadow` varchar(10) DEFAULT NULL,
  `display_dp` int(4) NOT NULL DEFAULT '1',
  `display_date` int(4) NOT NULL DEFAULT '1',
  `display_rating` int(4) NOT NULL DEFAULT '1',
  `display_review` int(4) NOT NULL DEFAULT '1',
  `font_size` varchar(5) DEFAULT NULL,
  `font_family` varchar(225) DEFAULT NULL,
  `status` int(11) NOT NULL DEFAULT '1',
  `is_social_share` int(5) NOT NULL DEFAULT '0',
  `meta_title` varchar(255) DEFAULT NULL,
  `meta_description` text,
  `meta_picture` varchar(100) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `client_payments`
--

CREATE TABLE `client_payments` (
  `id` int(11) NOT NULL,
  `mc_gross` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `protection_eligibility` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `tax` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `payment_status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `charset` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `first_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mc_fee` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `notify_version` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `custom` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_status` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `business` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `quantity` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `verify_sign` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payer_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `txn_id` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_type` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `last_name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `receiver_email` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_fee` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `receiver_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `txn_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_name` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `mc_currency` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `item_number` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `residence_country` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `test_ipn` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `handling_amount` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `transaction_subject` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `payment_gross` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `shipping` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `ipn_track_id` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_user` int(11) NOT NULL,
  `transaction_note` longtext COLLATE utf8_unicode_ci,
  `tran_type` varchar(100) COLLATE utf8_unicode_ci DEFAULT NULL,
  `firstData` longtext COLLATE utf8_unicode_ci,
  `api_payment` longtext COLLATE utf8_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `custom_reviews`
--

CREATE TABLE `custom_reviews` (
  `id` int(11) NOT NULL,
  `name` varchar(35) COLLATE latin1_general_ci DEFAULT NULL,
  `rating` varchar(5) COLLATE latin1_general_ci DEFAULT '4.5',
  `review` text COLLATE latin1_general_ci,
  `date` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `photo` text COLLATE latin1_general_ci,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` int(11) NOT NULL,
  `event_date` varchar(30) DEFAULT NULL,
  `event_message` text,
  `user_id` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `parent_id` varchar(100) DEFAULT NULL,
  `sender_name` varchar(100) DEFAULT NULL,
  `comment_id` varchar(100) DEFAULT NULL,
  `sender_id` varchar(100) DEFAULT NULL,
  `created_time` varchar(100) NOT NULL,
  `post_id` varchar(100) DEFAULT NULL,
  `message2` text,
  `action` varchar(25) DEFAULT NULL,
  `page_id` varchar(100) DEFAULT NULL,
  `page_token` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE `messages` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `reply_msg` text,
  `personal_msg` text NOT NULL,
  `reply_index` int(11) NOT NULL DEFAULT '1',
  `pm_index` int(11) NOT NULL DEFAULT '1',
  `sending_order` varchar(20) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `plans`
--

CREATE TABLE `plans` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `amount` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8_unicode_ci,
  `no_of_campaigns` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE `reports` (
  `id` int(11) NOT NULL,
  `parent_id` varchar(255) DEFAULT NULL,
  `sender_name` varchar(255) DEFAULT NULL,
  `comment_id` varchar(255) DEFAULT NULL,
  `sender_id` varchar(255) DEFAULT NULL,
  `created_time` varchar(255) DEFAULT NULL,
  `post_id` varchar(255) DEFAULT NULL,
  `message` text,
  `reply_id` varchar(255) DEFAULT NULL,
  `reply` text,
  `page_id` varchar(255) DEFAULT NULL,
  `action` varchar(255) DEFAULT NULL,
  `user_id` int(11) NOT NULL,
  `media_action` text,
  `attachment` text,
  `recipient_id` varchar(255) DEFAULT NULL,
  `message_id` varchar(255) DEFAULT NULL,
  `attachment_id` varchar(255) DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `version` varchar(10) NOT NULL DEFAULT '1.0',
  `business_email` varchar(255) DEFAULT NULL,
  `privacy_policy_url` text,
  `terms_conditions_url` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `email` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `password` varchar(30) COLLATE latin1_general_ci DEFAULT NULL,
  `type` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `name` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `address` text COLLATE latin1_general_ci,
  `status` int(11) NOT NULL DEFAULT '1',
  `plan` int(11) NOT NULL DEFAULT '0',
  `no_of_campaigns` int(11) NOT NULL DEFAULT '5',
  `app_id` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `app_secret` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `access_token` longtext COLLATE latin1_general_ci,
  `fb_error` longtext COLLATE latin1_general_ci,
  `response` text COLLATE latin1_general_ci,
  `response_code` text COLLATE latin1_general_ci,
  `subscription_id` text COLLATE latin1_general_ci,
  `paypal_subscriber_id` text COLLATE latin1_general_ci,
  `google_key` varchar(255) COLLATE latin1_general_ci DEFAULT NULL,
  `yelp_api_key` text COLLATE latin1_general_ci
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `web_user_info`
--

CREATE TABLE `web_user_info` (
  `id` int(11) NOT NULL,
  `pkg_id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `email` varchar(300) COLLATE utf8_unicode_ci DEFAULT NULL,
  `password` varchar(150) COLLATE utf8_unicode_ci DEFAULT NULL,
  `created_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `autoresponders`
--
ALTER TABLE `autoresponders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `campaigns`
--
ALTER TABLE `campaigns`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_payments`
--
ALTER TABLE `client_payments`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `custom_reviews`
--
ALTER TABLE `custom_reviews`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `messages`
--
ALTER TABLE `messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `plans`
--
ALTER TABLE `plans`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `web_user_info`
--
ALTER TABLE `web_user_info`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `autoresponders`
--
ALTER TABLE `autoresponders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `campaigns`
--
ALTER TABLE `campaigns`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_payments`
--
ALTER TABLE `client_payments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `custom_reviews`
--
ALTER TABLE `custom_reviews`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `messages`
--
ALTER TABLE `messages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `plans`
--
ALTER TABLE `plans`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `web_user_info`
--
ALTER TABLE `web_user_info`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
