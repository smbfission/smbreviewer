<script type="text/javascript" src="../assets/js/jquery.min.js"></script>
<script type="text/javascript" src="../assets/js/jquery_ui_min.js"></script>

<script type="text/javascript" src="../assets/js/bootstrap.min.js"></script>

<link type="text/css" href="../assets/css/bootstrap.min.css" rel="stylesheet" />