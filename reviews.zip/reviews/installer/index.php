<?php

include_once("admin_includes.php");

$loder_src = "../assets/images/lg.rotating-balls-spinner.gif";

$serverName = $_SERVER['SERVER_NAME'];

$filePath = $_SERVER['REQUEST_URI'];

$withInstall = substr($filePath,0,strrpos($filePath,'/'));

$serverPath = $_SERVER['SERVER_NAME'].substr($withInstall,0,strrpos($withInstall,'/')+1);
?>



<html>



    <head>



    <style>



    #content{



        margin:0;



    }



    #header{



        text-align: center;



        padding:2%;



    }



    #footer{



        margin: 0;



        text-align: center;



        width: 100%;



    }



    </style>



    <script type="text/javascript">



    $(document).ready(function(){

        $("#database_form").submit(function(res){
            
            console.log("step 0");

            $("#results1").html("");

            $("#loader1").show("slow");

            var data = $("#database_form").serializeArray();

            $.post("action.php",data,function(res){
                
                console.log("step 1");

                $("#loader1").hide("slow");

                if(res == "2" || res == 2)
                {
                    $("#results1").html("Could not connect, please check username or password");
                }
                else if(res == "3" || res == 3)
                {
                    $("#results1").html("Seems database doesn't exist");
                }
                else if(res == "1" || res == 1 )
                {
                    console.log("step 2");

                    $("#database_area").hide("slide", { direction: "left" }, 400);

                    $("#personal_area").delay(400).show("slide", { direction: "right" }, 400);

                    $('#progress_bar').css("width","50%");

                    //alert(res);

                }

            });

            return false;

        });


        $("#personal_form").submit(function(res){    

            $("#results3").html("");

            $("#loader3").show("slow");

            var data = $("#personal_form").serializeArray();

            $.post("action.php",data,function(res){

                $("#loader3").hide("slow");

                if(res == "2" || res == "3")

                {

                    $("#results3").html("Sorry! Your credentials are not saved");

                }

                else if (res == "1")

                {

                    $("#personal_area").hide("slide", { direction: "left" }, 400);

                    $("#complete_area").delay(400).show("slide", { direction: "right" }, 400);

                    $('#progress_bar').css("width","100%");

                    //alert(res);

                }

            });

            return false;

        });

   



        

        

        $('#check_db_conn').click(function(res){

            $("#results1").html("");

            $('#loader1').show("slow");

    		var hostName      = $('#hostname').val();

    		var userName      = $('#username').val();

    		var password      = $('#password').val();

    		var databaseName  = $('#database_name').val();

    		var QryStr='host_name='+hostName+'&user_name='+userName+'&password='+password+'&database_name='+databaseName+'&action=check_db';

    		$.post("action.php", QryStr, function(theResponse){	

        		$('#loader1').hide("slow");

                if(theResponse == '0')

        		{

        			var res = 'Could not connect';

        		}

        		else if(theResponse == '0')

                {

                	var res = 'Invalid Database or Incorrect Database Name</p>';

        		}

        		else if(theResponse == '1')

        		{

                    var res = 'Database connected successfully';	

        		}

        		else

        		{

        			var res = 'Some Error has Occured!';

        		}

                $("#results1").html(res);

        	});

         });	

    });



    </script>
    
    <title> Installer | Get My Reviews </title>



    </head>



    <body>



        <div class="panel panel-info" style="margin:0;">



            <div class="panel-heading" id="header">



                <h1>Get My Reviews</h1>



            </div>



            <div class="panel-body" id="container">



                <div class="progress progress-striped">



                  <div class="progress-bar progress-bar-success" role="progressbar" aria-valuenow="20" aria-valuemin="0" aria-valuemax="100" style="width:1%" id="progress_bar">



                    <span class="sr-only">1% Complete (success)</span>



                  </div>



                </div>


                <?php
                if(!isset($_SERVER["HTTPS"])){
                ?>
                <div style="width: 100%;">
                    <div class="alert alert-danger"><h3 align="Center">Warning : Domian in not secure as SSL is not enabled, Please run on SSL (https) secured domain otherwise application may not work.</h3></div>
                </div>
                <?php
                }
                ?>


                <div style="width: 100%;" id="database_area">



                    <div class="alert alert-success"><h3 align="Center">Enter Database Credentials</h3></div>



                    <form class="form-horizontal" role="form" name="database_form" id="database_form">



                      <input name="action" id="action" value="db_info" type="hidden"/>



                      <div class="form-group">



                        <label for="hostname" class="col-sm-2 control-label">Hostname (Usually this is the word localhost)</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="hostname" name="hostname" placeholder="Enter Database Hostname" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <label for="username" class="col-sm-2 control-label">Username</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="username" name="username" placeholder="Enter Database Username" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <label for="password" class="col-sm-2 control-label">Password</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="password" name="password" placeholder="Enter Database Password"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <label for="database_name" class="col-sm-2 control-label">Database Name</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="database_name" name="database_name"  placeholder="Enter Database Name" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <div class="col-sm-offset-2 col-sm-10">



                          <button type="button" class="btn btn-info" id="check_db_conn">Check Connection </button>



                          <button type="submit" class="btn btn-success">Proceed >> </button>

                          <img id="loader1" src="<?php echo $loder_src;?>" style="display: none; width:35;"/>

                          <span id="results1"></span>



                        </div>



                      </div>



                    </form>



                </div>



                



                <div style="width: 100%; display:none;" id="twilio_area">



                    <div class="alert alert-success"><h3 align="Center">Enter Twilio Credentials</h3></div>



                    <form class="form-horizontal" role="form" name="twilio_form" id="twilio_form">



                      <input name="action" id="action" value="twilio" type="hidden"/>



                      <div class="form-group">



                        <label for="twilio_sid" class="col-sm-2 control-label">Twilio Sid</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="twilio_sid" name="twilio_sid" placeholder="Enter Twilio Sid" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <label for="twilio_token" class="col-sm-2 control-label">Twilio Token</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="twilio_token" name="twilio_token" placeholder="Enter Twilio Token" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <div class="col-sm-offset-2 col-sm-10">



                          <button type="submit" class="btn btn-success">Proceed >> </button>

                          <img id="loader2" src="<?php echo $loder_src;?>" style="display: none; width:35;"/>

                          <span id="results2"></span> 



                        </div>



                      </div>



                    </form>



                </div>



                



                <div style="width: 100%; display:none;" id="personal_area">



                    <div class="alert alert-success"><h3 align="Center">Enter Personal Credentials</h3></div>



                    <form class="form-horizontal" role="form" name="personal_form" id="personal_form">



                      <input name="action" id="action" value="personal_info" type="hidden"/>



                      <div class="form-group">



                        <label for="name" class="col-sm-2 control-label">Name</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="name" name="name" placeholder="Enter Name" required="required"/>



                        </div>



                      </div>
                      
                      
                      
                      <div class="form-group">



                        <label for="email" class="col-sm-2 control-label">Email Address</label>



                        <div class="col-sm-10">



                          <input type="email" class="form-control" id="email" name="email" placeholder="Enter Email Address" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <label for="password" class="col-sm-2 control-label">Password</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="password" name="password" placeholder="Enter Password" required="required"/>



                        </div>

                      </div>
                      
                      <div class="form-group">



                        <label for="phone" class="col-sm-2 control-label">Phone</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="phone" name="phone" placeholder="Enter Phone" required="required"/>



                        </div>

                      </div>
                      
                      <div class="form-group">



                        <div class="col-sm-offset-2 col-sm-10">



                          <button type="submit" class="btn btn-success">Proceed >> </button> 

                          <img id="loader3" src="<?php echo $loder_src;?>" style="display: none; width:35;"/>

                          <span id="results3"></span> 

                          



                        </div>



                      </div>



                    </form>



                </div>



                



                <div style="width: 100%; display:none;" id="application_area">



                    <div class="alert alert-success"><h3 align="Center">Enter Application Credentials</h3></div>



                    <form class="form-horizontal" role="form" name="application_form" id="application_form">



                      <input name="action" id="action" value="app_info" type="hidden"/>



                      <div class="form-group">



                        <label for="application_url" class="col-sm-2 control-label">Application URL</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="application_url" name="application_url" disabled="disabled" required="required" value="<?php echo $serverPath; ?>"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <label for="keyword" class="col-sm-2 control-label">Default keyword</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="keyword" name="keyword" placeholder="Enter Default keyword" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">

                        <label for="paypal_email" class="col-sm-2 control-label">Paypal Email</label>

                        <div class="col-sm-10">

                          <input type="text" class="form-control" id="paypal_email" name="paypal_email" placeholder="Enter Application Title" required="required"/>

                        </div>

                      </div>

                      

                      <div class="form-group">



                        <label for="app_title" class="col-sm-2 control-label">Application Title</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="app_title" name="app_title" placeholder="Enter Application Title" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <label for="append_text" class="col-sm-2 control-label">Append Text</label>



                        <div class="col-sm-10">



                          <input type="text" class="form-control" id="append_text" name="append_text"  placeholder="Enter Append Text" required="required"/>



                        </div>



                      </div>



                      <div class="form-group">



                        <div class="col-sm-offset-2 col-sm-10">



                          <button type="submit" class="btn btn-success">Proceed >> </button> 

                          <img id="loader4" src="<?php echo $loder_src;?>" style="display: none; width:35;" />

                          <span id="results4"></span> 

                          

                        </div>



                      </div>



                    </form>



                </div>



                



                <div style="width: 100%; display:none;" id="complete_area" align="center">



                    <div class="alert alert-success"><h3 align="Center">Application Installed Successfully</h3>

                    Please Click <a href="<?php echo trim(geturls(),"/").'/index.php?action=login';?>">Here</a> to log into your Application.  AFTER LOGIN DONT FORGET TO UPDATE TO THE MOST RECENT VERSION!

                    </div>



                </div>



                



                



            </div>



        </div>



        <div class="alert alert-info" id="footer">



            <div style="font-size:16px;"> &copy; 2018 <a href="http://ranksol.com">Ranksol Web Solutions</a> </div>



        </div>



    </body>



</html>

<?php

function geturls()

{

    $serverName = $_SERVER['SERVER_NAME'];

    $filePath = $_SERVER['REQUEST_URI'];

    $withInstall = substr($filePath,0,strrpos($filePath,'/'));

    $serverPath = $_SERVER['SERVER_NAME'].substr($withInstall,0,strrpos($withInstall,'/')+1);

    $applicationPath = $serverPath;

    if(strpos($applicationPath,'http://www.')===false)

    {

    	if(strpos($applicationPath,'www.')===false)

    		$applicationPath = 'www.'.$applicationPath;

    	if(strpos($applicationPath,'http://')===false)

    		$applicationPath = 'http://'.$applicationPath;
    }
    
    if($serverName=='localhost'){
        $applicationPath = str_replace("www.","",$applicationPath);
    }
    
    return $applicationPath;
    
    
    
    

}

?>