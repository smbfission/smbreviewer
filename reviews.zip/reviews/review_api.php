<?php
include_once("database.php");
$reviews = array();
$data = array();
$sql = "select * from custom_reviews where user_id = '".$_REQUEST['uid']."'";
$exe = @mysqli_query($conn,$sql);
if(mysqli_num_rows($exe)>0){
    while($row = @mysqli_fetch_assoc($exe)){
        $row['photo'] = getServerURL()."/uploads/".$row['photo'];
        $data[] = $row;
    }
    $reviews['status'] = "success";
    $reviews['data'] = $data;
}else{
    $reviews['status'] = "error"; 
}
echo json_encode($reviews);


function getServerURL()
{
    $serverName = $_SERVER['SERVER_NAME'];
    $filePath = $_SERVER['REQUEST_URI'];
    $withInstall = substr($filePath,0,strrpos($filePath,'/')+1);
    $serverPath = $serverName.$withInstall;
    $applicationPath = $serverPath;
    
    if(strpos($applicationPath,'http://www.')===false)
    {
    if(strpos($applicationPath,'www.')===false)
    $applicationPath = 'www.'.$applicationPath;
    if(strpos($applicationPath,'http://')===false)
    $applicationPath = 'http://'.$applicationPath;
    }
    
    if(isset($_SERVER["HTTPS"])){
        $protocol = "https://";
    }else{
        $protocol = "http://";
    }
    
    $applicationPath = str_replace("www.","",$applicationPath);
    $applicationPath = str_replace("http://",$protocol,$applicationPath);
    $applicationPath = str_replace("https://",$protocol,$applicationPath);
        
    return $applicationPath;
}