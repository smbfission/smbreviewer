<?php
include_once("header.php");
include_once("sidebar.php");

?>
    <link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
          <section role="main" class="content-body">
					<header class="page-header">
						<h2>Members Add / Edit</h2>
					
						<div class="right-wrapper pull-right" style="display:none;">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Tables</span></li>
								<li><span>Advanced</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>
                    
                    <div class="row">
						<div class="col-lg-12">
							<section class="panel">
								<div class="panel-body">
                                
                                    <div class="row">
                                        <div class="col-sm-12">
            								<h2 class="h2 mt-none mb-sm text-dark text-bold">
                                                Members
                                            </h2>
            								<p class="text-muted font-13 m-b-15">                                            
                                                <!-- Description Goes Here <br /> -->
                                                &nbsp;
                                            </p>
            							</div>
                                        
                                        
                                        <?php
                                        if(isset($_SESSION['msg']) && $_SESSION['msg']!=""){
                                            ?>
                                            <div class="col-sm-12">
                                                <div class="alert alert-info"><?php echo $_SESSION['msg']; ?></div>
                                            </div>
                                            <?php
                                            unset($_SESSION['msg']);
                                        }
                                        ?>
                                    </div>
                                
                                    
                                    <?php
                            
    							$sql = "SELECT * FROM `user` where id = '".@$_REQUEST['id']."'";
    							$result = $conn->query($sql);
    							$row = $result->fetch_assoc();
                                
    							?>
                                    
                                    

                                    <form action="action.php?action=member" class="form-horizontal form-bordered"  method="post">
    									
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Name</label>
											<div class="col-md-6">
                                                <input class="form-control" name="name" value="<?php echo @$row['name'] ?>" type="text">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Email</label>
											<div class="col-md-6">
                                                <input class="form-control" name="email" value="<?php echo @$row['email'] ?>" type="email">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Password</label>
											<div class="col-md-6">
                                                <input class="form-control" name="password" value="<?php echo @$row['password'] ?>" type="password">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Phone</label>
											<div class="col-md-6">
                                                <input class="form-control" name="phone" value="<?php echo @$row['phone'] ?>" type="phone">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Choose Plan</label>
											<div class="col-md-6">
                                                <select class="form-control" id="plan" name="plan">
    											  <?php
    									    $sql = "SELECT * FROM `plans`";
    										$result = $conn->query($sql);
    										if ($result->num_rows > 0) {
    											// output data of each row
    											while($plans = $result->fetch_assoc()) {
    											?>
    											<option <?php if(@$row['plan'] == $plans['id']){ echo "selected='selected'"; }?> value="<?php echo $plans['id'];?>"><?php echo $plans['title'];?></option><?php
    											}
    												} else {
    													echo "0 results";
    												}
    											?>
    												
    											  </select>
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault"></label>
											<div class="col-md-6">
                                                <input type="hidden" name="id" value="<?php echo @$row['id']; ?>">
											    <button type="submit" name="submit" value="submit"  class="btn  btn-fill btn-success "><span class="ace-icon fa fa-save bigger-120"></span> Save</button>
											</div>
										</div>
                                        	
    								</form>
                                </div>
							</section>
                        </div>
                    </div>
                    <!-- end: page -->
				</section>
			</div>
            
            </section>

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
		<script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
		
		<!-- Specific Page Vendor -->
		<script src="assets/vendor/jquery-autosize/jquery.autosize.js"></script>
		<script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>

	</body>
</html>