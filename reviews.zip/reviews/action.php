<?php
include('database.php');

if(isset($_REQUEST))
{   
    if($_REQUEST['action'] == "plans")
    {
        if($_REQUEST['id']!="" && $_REQUEST['id']!="0")
        {
            $sql = "update `plans` set `title` = '".$_REQUEST['title']."' ,`description` = '".$_REQUEST['description']."', `amount` = '".$_REQUEST['amount']."', no_of_campaigns = '".$_REQUEST['no_of_campaigns']."' where id = '".$_REQUEST['id']."'";    
            if($conn->query($sql)){
                $_SESSION['msg'] = 'Plan Updated Successfully';
                header('location:plans.php');
            }
        }
        else
        {
            $sql = "INSERT INTO `plans`(`title`,`amount`, `description`,`no_of_campaigns`) VALUES ('".$_REQUEST['title']."','".$_REQUEST['amount']."','".$_REQUEST['description']."','".$_REQUEST['no_of_campaigns']."')";    
            if($conn->query($sql)){
                $_SESSION['msg'] = 'Plan Created Successfully';
                header('location:plans.php');
            }
        }
    }else
    if($_REQUEST['action'] == "custom_reviews")
    {
        
        $photo = $_REQUEST['hidden_photo'];
        if(isset($_FILES["photo"])){
            $target_dir = "uploads/";
            $rand = rand(9,999999);
            $target_file = $target_dir . $rand.basename($_FILES["photo"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            if (move_uploaded_file($_FILES["photo"]["tmp_name"], $target_file)) {
                $photo = $rand.basename( $_FILES["photo"]["name"]);
            }
        }
        
        $_REQUEST['date'] = date("Y-m-d",strtotime($_REQUEST['date']));
        
        if(@$_REQUEST['id']!="" && @$_REQUEST['id']!="0")
        {
            $sql = "update `custom_reviews` set `name` = '".$_REQUEST['name']."' ,`rating` = '".$_REQUEST['rating']."', `review` = '".$_REQUEST['review']."', `date` = '".$_REQUEST['date']."', `photo` = '".$photo."', user_id = '".$_SESSION['user_id']."' where id = '".$_REQUEST['id']."'";    
            if($conn->query($sql)){
                $_SESSION['msg'] = 'Review Updated Successfully';
                header('location:custom_reviews.php');
            }
        }
        else
        {
            $sql = "INSERT INTO `custom_reviews`(`name`,`rating`, `review`,`date`, `photo`, `user_id`) VALUES ('".$_REQUEST['name']."','".$_REQUEST['rating']."','".$_REQUEST['review']."','".$_REQUEST['date']."','".$photo."','".$_SESSION['user_id']."')";    
            if($conn->query($sql)){
                $_SESSION['msg'] = 'Review Created Successfully';
                header('location:custom_reviews.php');
            }
        }
    }
    else
    if($_REQUEST['action'] == "delete_plan")
    {
        $sql = "delete from `plans` where id = '".$_REQUEST['id']."'";    
        if($conn->query($sql)){
            header('location:plans.php');
        }
    }
    else
    if($_REQUEST['action'] == "delete_review")
    {
        $sql = "delete from `custom_reviews` where id = '".$_REQUEST['id']."'";    
        if($conn->query($sql)){
            header('location:custom_reviews.php');
        }
    }
    else
    if($_REQUEST['action'] == "profile")
    {
        $sql = "update `user` set `name` = '".$_REQUEST['name']."' ,`email` = '".$_REQUEST['email']."', `password` = '".$_REQUEST['password']."', phone = '".$_REQUEST['phone']."'  where id = '".$_REQUEST['id']."'";    
        if($conn->query($sql)){
            $_SESSION['msg'] = 'Profile Updated Successfully';
            header('location:profile.php');
        }
    }
    else
    if($_REQUEST['action'] == "member")
    {
        
        $sql_plan = "select * from plans where id = '".$_REQUEST['plan']."'";
        $exe_plan = mysqli_query($conn,$sql_plan);
        $row_plan = mysqli_fetch_assoc($exe_plan);
        
        
        if($_REQUEST['id']!="" && $_REQUEST['id']!="0")
        {
            $sql_ck = "select * from user where email = '".$_REQUEST['email']."' and id != '".$_REQUEST['id']."'";
            $exe_ck = mysqli_query($conn,$sql_ck);
            $row_ck = mysqli_num_rows($exe_ck);
            if($row_ck==0)
            {
                $sql = "update `user` set `name` = '".$_REQUEST['name']."' ,`email` = '".$_REQUEST['email']."', `password` = '".$_REQUEST['password']."', address = '".@$_REQUEST['address']."', phone = '".$_REQUEST['phone']."', plan = '".$_REQUEST['plan']."', no_of_campaigns = '".$row_plan['no_of_campaigns']."' where id = '".$_REQUEST['id']."'";    
                if($conn->query($sql)){
                    $_SESSION['msg'] = 'Member Updated Successfully';
                    header('location:members.php');
                }
            }
            else{
                $_SESSION['msg'] = 'Email Already Exist';
                header('location:members.php');
            }
        }
        else
        {
            $sql_ck = "select * from user where email = '".$_REQUEST['email']."'";
            $exe_ck = mysqli_query($conn,$sql_ck);
            $row_ck = mysqli_num_rows($exe_ck);
            if($row_ck==0)
            {
                $sql = "INSERT INTO `user`(`name`,`email`, `password`,`address`,`phone`,`type`,`plan`,`no_of_campaigns`) VALUES ('".$_REQUEST['name']."','".$_REQUEST['email']."','".$_REQUEST['password']."','".@$_REQUEST['address']."','".$_REQUEST['phone']."','2','".$_REQUEST['plan']."','".$row_plan['no_of_campaigns']."')";    
                if($conn->query($sql)){
                    $_SESSION['msg'] = 'Member Created Successfully';
                    header('location:members.php');
                }
            }
            else{
                $_SESSION['msg'] = 'Email Already Exist';
                header('location:members.php');
            }
        }
    }
    else
    if($_REQUEST['action'] == "delete_member")
    {
        $sql_ck = "select id,fb_page,page_token from campaigns where user_id = '".$_REQUEST['id']."'";
        $exe_ck = mysqli_query($conn,$sql_ck);
        while($row_ck = mysqli_fetch_assoc($exe_ck))
        {
            $json_resp = removePageSubscription($row_ck['fb_page'],$row_ck['page_token']);
        }
        
        $del_campa = "delete from campaigns where user_id = '".$_REQUEST['id']."'";
        mysqli_query($conn,$del_campa);
        
        
        $sql = "select id,app_id,app_secret from user where id = '".$_REQUEST['id']."'";
        $exe = @mysqli_query($conn,$sql);
        $row = @mysqli_fetch_assoc($exe);
        
        removeAppSubscription($row['app_id'],$row['app_secret']);
        
        $sql = "delete from `user` where id = '".$_REQUEST['id']."'";    
        if($conn->query($sql)){
            $_SESSION['msg'] = "Member Successfully Deleted";
        }
        header('location:members.php');
        
    }
    else
    if($_REQUEST['action'] == "delete_msg")
    {
        $sql = "delete from `messages` where id = '".$_REQUEST['id']."'";    
        if($conn->query($sql)){
            header('location:messages.php');
        }
    }
    else
    if($_REQUEST['action'] == "delete_auto")
    {
        $sql = "delete from `autoresponders` where id = '".$_REQUEST['id']."'";    
        if($conn->query($sql)){
            header('location:autoresponders.php');
        }
    }
    else
    if($_REQUEST['action'] == "save_campaigns"){
        $sql = "INSERT INTO `campaigns` (`title`,`user_id`) values ('".$_REQUEST['title']."','".$_SESSION['user_id']."')";
        if($conn->query($sql)){
            $insert_id = $conn->insert_id;
            header('location:campaign_add.php?id='.$insert_id);
        }else{
            echo $_SESSION['msg'] = $conn->error;
            header('location:campaign.php');
        }
        
    }
    else
    if($_REQUEST['action'] == "campaigns")
    {   
        $title=mysqli_real_escape_string($conn, $_REQUEST['title']);
        $fb_page=explode("|",$_REQUEST['fb_page']);
        
        if(isset($_REQUEST['is_facebook'])){
            $is_facebook = 1;
        }else{
            $is_facebook = 0;
        }
        
        if(isset($_REQUEST['is_google'])){
            $is_google = 1;
        }else{
            $is_google = 0;
        }
        
        if(isset($_REQUEST['is_yelp'])){
            $is_yelp = 1;
        }else{
            $is_yelp = 0;
        }
        
        if(isset($_REQUEST['is_custom'])){
            $is_custom = 1;
        }else{
            $is_custom = 0;
        }
        
        if(isset($_REQUEST['is_social_share'])){
            $is_social_share = 1;
        }else{
            $is_social_share = 0;
        }
        
        if(isset($_REQUEST['display_dp'])){
            $display_dp = 1;
        }else{
            $display_dp = 0;
        }
        
        if(isset($_REQUEST['display_date'])){
            $display_date = 1;
        }else{
            $display_date = 0;
        }
        
        if(isset($_REQUEST['display_rating'])){
            $display_rating = 1;
        }else{
            $display_rating = 0;
        }
        
        if(isset($_REQUEST['display_review'])){
            $display_review = 1;
        }else{
            $display_review = 0;
        }
        
        $meta_description = mysqli_real_escape_string($con,$_REQUEST['meta_description']);
        
        
        $meta_picture = $_REQUEST['hidden_meta_picture'];
        if(isset($_FILES["meta_picture"])){   
            $target_dir = "uploads/";
            $target_file = $target_dir . basename($_FILES["meta_picture"]["name"]);
            $uploadOk = 1;
            $imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
            
            if (move_uploaded_file($_FILES["meta_picture"]["tmp_name"], $target_file)) {
                $meta_picture = basename( $_FILES["meta_picture"]["name"]);
            }
        }
        
        if(@$_REQUEST['id']!="" && @$_REQUEST['id']!="0")
        {
            $sql = "update `campaigns` set `title` = '".$title."' ,`fb_page` = '".@$fb_page[0]."', `page_name` = '".@$fb_page[1]."', `page_token` = '".@$fb_page['2']."', `google_business` = '".$_REQUEST['google_business']."', `yelp_business_id` = '".$_REQUEST['yelp_business_id']."', `place_id` = '".$_REQUEST['place_id']."',
             `is_social_share` = '".$is_social_share."', `meta_title` = '".$_REQUEST['meta_title']."',  `meta_description` = '".$meta_description."', `meta_picture` = '".$meta_picture."', 
             `is_facebook` = '".$is_facebook."', `is_google` = '".$is_google."', `is_yelp` = '".$is_yelp."', `is_custom` = '".$is_custom."',  `style` = '".$_REQUEST['style']."', `widget_bg_color` = '".$_REQUEST['widget_bg_color']."', widget_box_shadow = '".$_REQUEST['widget_box_shadow']."', `name_color` = '".$_REQUEST['name_color']."', `rating_color` = '".$_REQUEST['rating_color']."', date_color = '".$_REQUEST['date_color']."', review_color = '".$_REQUEST['review_color']."', display_dp = '".$display_dp."', display_date = '".$display_date."', display_rating = '".$display_rating."', display_review = '".$display_review."', font_size = '".$_REQUEST['font_size']."', font_family = '".$_REQUEST['font_family']."' where id = '".$_REQUEST['id']."'";    
            if($conn->query($sql)){
                header('location:'.$_SERVER['HTTP_REFERER']);
            }
        }
        else
        {            
            $sql = "INSERT INTO `campaigns`(`title`,`fb_page`,`page_name`,`page_token`,`google_business`, `yelp_business_id`, `place_id` , `is_facebook`, `is_google`, `is_yelp`, `style`, `name_color`, `rating_color`, `date_color`,`review_color`,`display_dp`,`display_date`,`display_rating`,`display_review`,`font_size`,`font_family`,`user_id`,`widget_bg_color`,`widget_box_shadow`,`is_social_share`,`meta_title`,`meta_description`,`meta_picture`, `is_custom`) VALUES 
            ('".$title."','".@$fb_page[0]."','".@$fb_page[1]."','".@$fb_page[2]."','".$_REQUEST['google_business']."','".$_REQUEST['yelp_business_id']."','".$_REQUEST['place_id']."','".$is_facebook."','".$is_google."','".$is_yelp."','".$_REQUEST['style']."','".$_REQUEST['name_color']."','".$_REQUEST['rating_color']."', '".$_REQUEST['date_color']."','".$_REQUEST['review_color']."','".$display_dp."','".$display_date."','".$display_rating."','".$display_review."','".$_REQUEST['font_size']."','".$_REQUEST['font_family']."','".$_SESSION['user_id']."','".$_REQUEST['widget_bg_color']."','".$_REQUEST['widget_box_shadow']."','".$is_social_share."','".$_REQUEST['meta_title']."','".$meta_description."','".$meta_picture."','".$_REQUEST['is_custom']."')";
            if($conn->query($sql)){
                $_SESSION['msg'] = 'Campaign added successfully';
                header('location:campaign.php');
            }else{
                echo $_SESSION['msg'] = $conn->error;
                header('location:campaign.php');
            }
        }
        
        die();
        
    }
    else
    if($_REQUEST['action'] == "delete_camp")
    {   
        $sql = "delete from `campaigns` where id = '".$_REQUEST['id']."'";    
        if($conn->query($sql)){
            header('location:campaign.php');
        }
    }
    else
    if($_REQUEST['action'] == "page_reviews")
    {
        $page_id = explode("|",$_REQUEST['page_id']);
        $url="https://graph.facebook.com/$page_id[0]/ratings?access_token=$page_id[2]&limit=100&fields=created_time,has_rating,has_review,open_graph_story,rating,review_text,reviewer";
        $json=post_fb($url,"get");
        echo $json;
        die();                             
    }
    else
    if($_REQUEST['action'] == "place_reviews")
    {
        $sql = "select google_key from user where id = '".$_SESSION['user_id']."'";
        $exe = mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($exe);
        
        $place_id = $_REQUEST['place_id'];
        $url="https://maps.googleapis.com/maps/api/place/details/json?placeid=$place_id&fields=name,rating,formatted_phone_number,reviews&key=$row[google_key]";
        $json=post_fb($url,"get");
        echo $json;
        die();                            
    }
    else
    if($_REQUEST['action'] == "yelp_reviews")
    {   
        $sql = "select yelp_api_key from user where id = '".$_SESSION['user_id']."'";
        $exe = mysqli_query($conn,$sql);
        $row = mysqli_fetch_assoc($exe);
        
        $business_id=$_REQUEST['business_id'];
        $url="https://api.yelp.com/v3/businesses/$business_id/reviews";
        echo $yelp_json = post_fb($url,"get","",$row['yelp_api_key']);
        die();
    }
}



function getServerURL()
{
    $serverName = $_SERVER['SERVER_NAME'];
    $filePath = $_SERVER['REQUEST_URI'];
    $withInstall = substr($filePath,0,strrpos($filePath,'/')+1);
    $serverPath = $serverName.$withInstall;
    $applicationPath = $serverPath;
    
    if(strpos($applicationPath,'http://www.')===false)
    {
    if(strpos($applicationPath,'www.')===false)
    $applicationPath = 'www.'.$applicationPath;
    if(strpos($applicationPath,'http://')===false)
    $applicationPath = 'http://'.$applicationPath;
    }
    $applicationPath = str_replace("www.","",$applicationPath);    
    return $applicationPath;
}


function removePageSubscription($fb_page,$page_token){
    $url="https://graph.facebook.com/$fb_page/subscribed_apps?access_token=$page_token";
    $un_subscribed_app=post_fb($url,"delete");
    //$posts=json_decode($un_subscribed_app,true);
    return $un_subscribed_app; 
    //print_r($posts);
    //echo "<br />Removed Old $row_ck[page_name] Subscription<br /><br />";
}

function addPageSubscription($fb_page,$page_token)
{
    $url="https://graph.facebook.com/$fb_page/subscribed_apps?access_token=$page_token";
    $subscribed_apps=post_fb($url,"post");
    //$posts=json_decode($subscribed_apps,true);
    return $subscribed_apps; 
    //print_r($posts);
    //echo "<br />Subscribed $_REQUEST[page_name] Successfully <br /><br />";
}

function removeAppSubscription($app_id,$app_secret)
{
    $app_access_token = $app_id."|".$app_secret;
    $url="https://graph.facebook.com/$app_id/subscriptions?access_token=$app_access_token";
    $data = array();
    $data['object'] = "page";
    // $data['fields'] = "feed,name"; // Uncommnet to Remove Specific Fields. 
    $un_subscribed_app=post_fb2($url,"post",$data);
    $posts=json_decode($un_subscribed_app,true);
    return $posts; 
}

function post_fb($url,$method,$body="",$apiKey=""){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url );
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 100);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    
    if($apiKey!=""){
        $headr[] = 'Authorization: Bearer '.$apiKey;
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headr);
    }
    
    if($method == "post"){
        curl_setopt($ch, CURLOPT_POST, true );
        //curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    else if($method=="delete")
    {
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    }
    else{
        curl_setopt($ch, CURLOPT_HTTPGET, true );   
    }   
    return curl_exec($ch);
}

function post_fb2($url,$method,$body=""){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url );
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 100);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if($method == "post"){
        curl_setopt($ch, CURLOPT_POST, true );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "DELETE");
    }
    else{
        curl_setopt($ch, CURLOPT_HTTPGET, true );   
    }   
    return curl_exec($ch);
}
?>