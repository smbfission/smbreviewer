				<?php
                include_once("header.php");
                include_once("sidebar.php");
                ?>

				<section role="main" class="content-body">
					<header class="page-header">
						<h2>Campaigns</h2>
					
						<div class="right-wrapper pull-right" style="display:none;">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Tables</span></li>
								<li><span>Advanced</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>

					<!-- start: page -->
						<section class="panel">
						    <div class="panel-body">
								<div class="row">
                                    <div class="col-sm-12">
        								<h2 class="h2 mt-none mb-sm text-dark text-bold">
                                            Campaigns
                                            <?php
                                            $sql3 = "SELECT no_of_campaigns from user where id = '".$_SESSION['user_id']."'";
        									$result3 = mysqli_query($conn,$sql3);
                                            $records3 = mysqli_fetch_assoc($result3);
                                            
                                            //print_r($records3);
                                            
                                            $no_of_campaigns = $records3['no_of_campaigns'];
                                            
                                            
        									$sql2 = "SELECT id from campaigns where user_id = '".$_SESSION['user_id']."'";
        									$result2 = mysqli_query($conn,$sql2);
                                            $records2 =  mysqli_num_rows($result2);
                                            
        									if ($records2 <= $no_of_campaigns) {
        									   if($no_of_campaigns>"0")
                                               {
        									   ?>
        									 	<a class="btn btn-fill btn-primary pull-right m-t-20" data-toggle="modal" data-target="#con-close-modal">Add New Campaign</a>
                                                <?php
        									   }
                                            }
                                            ?>
                                            
                                            <div id="con-close-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="display: none;">
                                                <form action="action.php?action=save_campaigns" method="post">
                                                <div class="modal-dialog">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
                                                            <h4 class="modal-title">Create a new campaign</h4>
                                                        </div>
                                                        <div class="modal-body">
                                                            <div class="row">
                                                                <div class="col-md-12">
                                                                    <div class="form-group">
                                                                        <label for="title" class="control-label">Campain Name</label>
                                                                        <input type="text" class="form-control" id="title" name="title">
                                                                    </div>
                                                                </div>
                                                            </div>
                                                            
                                                            
                                                            
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-info waves-effect waves-light">Save and Next</button>
                                                        </div>
                                                    </div>
                                                </div>
                                                </form>
                                            </div><!-- /.modal -->
                                        </h2>
        								<p class="text-muted font-13 m-b-15">                                            
                                            <!-- Description Goes Here <br /> -->
                                            &nbsp;
                                        </p>
        							</div>
                                    
                                    
                                    <?php
                                    if(isset($_SESSION['msg']) && $_SESSION['msg']!=""){
                                        ?>
                                        <div class="col-sm-12">
                                            <div class="alert alert-info"><?php echo $_SESSION['msg']; ?></div>
                                        </div>
                                        <?php
                                        unset($_SESSION['msg']);
                                    }
                                    ?>
                                    
                                </div>
                                
                                <!-- <table class="table table-bordered table-striped mb-none" id="datatable-default"> -->
								<table id="datatable-responsive"
                                           class="table table-striped  table-colored table-info dt-responsive nowrap" cellspacing="0"
                                           width="100%" style="font-size:12px;">
                                        <thead>
                                            <tr>
                                                <th>Sr#</th>
                                                <th>Title</th>
                                            	<th>Facebook Reviews</th>
                                            	<th>Google Reviews</th>
                                                <th>Yelp Reviews</th>
                                                <th>Custom Reviews</th>
        										<th>Created date</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
        									$sql = "SELECT * from campaigns where user_id = '".$_SESSION['user_id']."'";
    										$result = $conn->query($sql);
                                            $records = $result->num_rows;
    
    										if ($records > 0) {
    										  $sr = 1;
    											while($row = $result->fetch_assoc()) {
    											?>
													
                                        <tr>
                                        	<td><?php echo $sr++;?></td>
                                        	<td><?php echo $row['title'];?></td>
                                        	<td><?php if($row['is_facebook']=="1"){ echo '<label class="label label-success">Enabled<label>'; }else{ echo '<label class="label label-warning">Disabled<label>'; } ?></td>
                                            <td><?php if($row['is_google']=="1"){ echo '<label class="label label-success">Enabled<label>'; }else{ echo '<label class="label label-warning">Disabled<label>'; } ?></td>
                                            <td><?php if($row['is_yelp']=="1"){ echo '<label class="label label-success">Enabled<label>'; }else{ echo '<label class="label label-warning">Disabled<label>'; } ?></td>
                                            <td><?php if($row['is_custom']=="1"){ echo '<label class="label label-success">Enabled<label>'; }else{ echo '<label class="label label-warning">Disabled<label>'; } ?></td>
                                            <td><?php echo $row['created_date']; ?></td>
                                            <td>	
                                                <!--- Start of Action Coloum-->
    											<div class="hidden-sm hidden-xs btn-group">
    												<a href="campaign_add.php?id=<?php echo $row['id']; ?>" class="btn btn-fill btn-xs btn-info">
    													<i class="ace-icon fa fa-pencil bigger-120"></i>
    												</a>
                                                    
    												<a onclick="return deleteMe('action.php?id=<?php echo $row['id']; ?>&action=delete_camp')" class="btn btn-fill btn-xs btn-danger">
    													<i class="ace-icon fa fa-trash-o bigger-120"></i>
    												</a>
    											</div>
                                                <!--- End of Action Colum-->
    										</td>
                                        
											
											
											
											
                                        </tr>
<?php
											}
										} else {
											//echo "No Records Found";
										}
						?>	
                                        </tbody>
                                    </table>
							</div>
						</section>            
					<!-- end: page -->
				</section>
			</div>
            
		</section>

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
		<script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
		
		<!-- Specific Page Vendor -->
		<script src="assets/vendor/select2/select2.js"></script>
		<script src="assets/vendor/jquery-datatables/media/js/jquery.dataTables.js"></script>
		<script src="assets/vendor/jquery-datatables/extras/TableTools/js/dataTables.tableTools.min.js"></script>
		<script src="assets/vendor/jquery-datatables-bs3/assets/js/datatables.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>


		<!-- Examples -->
		<script src="assets/javascripts/tables/examples.datatables.default.js"></script>
		<script src="assets/javascripts/tables/examples.datatables.row.with.details.js"></script>
		<script src="assets/javascripts/tables/examples.datatables.tabletools.js"></script>
        <script>
        
        function deleteMe(url){
            if(confirm("Are you sure?")){
                window.location = url;
            }
            return false;
        }
        
        </script>
        
	</body>
</html>