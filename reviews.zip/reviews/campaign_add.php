<?php
include_once("header.php");
include_once("sidebar.php");

$fonts = ["Arial","Times","Courier","Verdana","Georgia","Palatino","Comic Sans MS","Trebuchet MS","Arial Black","Impact"];
$facebook_json = "";
$google_json = "";
$custom_json = "";
?>
<script>
function getReviews(obj){
    $( "#reviews" ).prepend("<center class='m-t-50'><img src='assets/img/ajax-loader-black-bar.gif' width='75px'/></center>");
    var str = $(obj).val()
    var qry = "action=page_reviews&page_id="+str;
    $.post( "action.php",qry, function( data ) {
      
      $("#json_container_facebook").text(data);
      changeStyle($("input[name='style']:checked").val());
    });
}

function getYelpReviews(){
    $( "#reviews" ).prepend("<center class='m-t-50'><img src='assets/img/ajax-loader-black-bar.gif' width='75px'/></center>");
    var qry = "action=yelp_reviews&business_id="+$("#yelp_business_id").val();
    $.post( "action.php",qry, function( data ) {
      
      $("#json_container_yelp").text(data);
      changeStyle($("input[name='style']:checked").val());
    });
}

function getcustomReviews(){
    $( "#reviews_loader" ).html("<center class='m-t-50'><img src='assets/img/ajax-loader-black-bar.gif' width='75px'/></center>");
    var qry = "uid=<?php echo $_SESSION['user_id']; ?>";
    $.post( "review_api.php",qry, function( data ) {
      $( "#reviews_loader" ).html("");
      $("#json_container_custom").text(data);
      changeStyle($("input[name='style']:checked").val());
    });
}

function addRating(){
    $("#reviews .user-rating").each(function(){
        var score = $(this).html();
        var color = $("#rating_color").val();
        $(this).html("");
        $(this).rateYo({
            rating : score,
            starWidth: "15px",
            ratedFill: color,
            readOnly: true,
        })
    })
}

function applyFont(obj){
    $(".r_review").css("font-size",$(obj).val());
}

function applyFontFamily(obj){
    $(".r_review").css("font-family",$(obj).val());
}

</script>

<style>
.text-danger {
    font-size: 11px;
}
.switch{
    width:90%;
}
.code {
    padding: 6px 5%;
    color: #c7254e;
    background-color: #f9f2f4;
}
.select2-container .select2-choice{
    height: 35px !important;
    line-height: 21px !important;
}
.jq-ry-container{
    padding:0 !important;
}
.carousel-caption{
    padding:30px 55px;
    position: unset;
    text-shadow:none;
    color:inherit;
}
.carousel-inner > .item{
    padding-top:10px;
}
.code {
    padding: 6px 5%;
    color: #c7254e;
    background-color: #f9f2f4;
}
.thumbnail{
    padding: 10px 10px 0px 10px;
}

.carousel-control span {
    position: absolute;
    top: 50%;
    z-index: 5;
    display: inline-block;
    font-size: 30px;
}

.img-responsive{
    display: block;
    max-width: 100%;
    height: auto;    
}

</style>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">
<link rel="stylesheet" href="assets/vendor/bootstrap-colorpicker/css/bootstrap-colorpicker.css" />
<link rel="stylesheet" href="assets/vendor/select2/select2.css" />

<section role="main" class="content-body">
					<header class="page-header">
						<h2>Campaign</h2>
					
						<div class="right-wrapper pull-right" style="display:none;">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Tables</span></li>
								<li><span>Advanced</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>
                    
                    <div class="row">
						<div class="col-lg-12">
							<section class="panel">
								<div class="panel-body">
                                
                                    <div class="row">
                                        <div class="col-sm-12">
            								<h2 class="h2 mt-none mb-sm text-dark text-bold">
                                                Campaign
                                            </h2>
            								<p class="text-muted font-13 m-b-15">                                            
                                                <!-- Description Goes Here <br /> -->
                                                &nbsp;
                                            </p>
            							</div>
                                        
                                        
                                        <?php
                                        if(isset($_SESSION['msg']) && $_SESSION['msg']!=""){
                                            ?>
                                            <div class="col-sm-12">
                                                <div class="alert alert-info"><?php echo $_SESSION['msg']; ?></div>
                                            </div>
                                            <?php
                                            unset($_SESSION['msg']);
                                        }
                                        ?>
                                    </div>

                                    <?php
                                    $sql = "select * from user where id = '".$_SESSION['user_id']."'";
                                    $exe = @mysqli_query($conn,$sql);
                                    $settings = @mysqli_fetch_assoc($exe);
                                    $access_token = @$settings['access_token'];
                                    $yelp_api_key = @$settings['yelp_api_key'];
                                    
                                    
                                    $fb_pages = array();
                                    
                                    $sql_pages = "SELECT fb_page FROM `campaigns` where user_id = '".$_SESSION['user_id']."'";
        							$result_pages = $conn->query($sql_pages);
        							while($row_pages = $result_pages->fetch_assoc()){
        							    $fb_pages[] = @$row_pages['fb_page'];
        							}
                                    
        							$sql = "SELECT * FROM `campaigns` where id = '".@$_REQUEST['id']."'";
        							$result = $conn->query($sql);
        							$row = $result->fetch_assoc();
                                    
                                    if(isset($_REQUEST['id']) && $_REQUEST['id']!="" && $_REQUEST['id']!="0"){
                                        $key = array_search($row['fb_page'],$fb_pages);
                                        if(is_int($key)){
                                            unset($fb_pages[$key]);
                                        }
                                    }
                                    
                                    if(@$row['is_facebook']==1){
                                        $url="https://graph.facebook.com/$row[fb_page]/ratings?access_token=$row[page_token]&limit=100&fields=created_time,has_rating,has_review,open_graph_story,rating,review_text,reviewer";
                                        $facebook_json=post_fb($url,"get");
                                    }
                                    
                                    if(@$row['is_google']==1){
                                        $url="https://maps.googleapis.com/maps/api/place/details/json?placeid=$row[place_id]&fields=name,rating,formatted_phone_number,reviews&key=".@$settings['google_key'];
                                        $google_json=post_fb($url,"get"); 
                                    }
                                    
                                    if(@$row['is_yelp']==1){
                                        $url="https://api.yelp.com/v3/businesses/$row[yelp_business_id]/reviews";
                                        $yelp_json = post_fb($url,"get","",$yelp_api_key);
                                    }
                                    
                                    if(@$row['is_custom']==1){
                                        $url=getServerURL()."review_api.php?uid=".$_SESSION['user_id'];
                                        $custom_json=post_fb($url,"get"); 
                                    }
                                    
                                    
        							?>
                            
                                <div id="map" style="display: none;"></div>
								<form action="action.php?action=campaigns" id="campaign_form" method="post" enctype="multipart/form-data" class="form-horizontal form-bordered">
                                    
                                    <div class="form-group">
										<label class="col-md-3 control-label" for="inputDefault">Campain Name:</label>
										<div class="col-md-6">
                                            <input class="form-control" name="title" value="<?php echo @$row['title'] ?>" type="text">
                                            <input type="hidden" name="social_type" id="social_type" value="1">
										</div>
									</div>
                                    
                                    <div class="form-group">
										<label class="col-md-3 control-label" for="inputDefault">Facebook:</label>
										<div class="col-md-6">
                                            <input id="is_facebook" value="1" name="is_facebook" type="checkbox" onclick="showHidePlatform(this,'facebook')" <?php if(@$row['is_facebook']=="1"){ echo "checked"; } ?> />
                                            <label for="is_facebook"> Connent your Facebook Pages / Business</label>
                                            <?php
                                            if(trim(@$settings['access_token'])=="" || trim(@$settings['app_id'])=="" || trim(@$settings['app_secret'])==""){
                                            ?>
                                            <br /><span class="text-danger"><i class="fa fa-warning"></i> Facebook App credentials are missing! Please add <a href="settings.php">here</a> to get Facebook page reviews</span>
                                            <?php
                                            }
                                            ?>
										</div>
									</div>
                                    
                                    <div class="form-group" id="f_area" style="display: <?php if(@$row['is_facebook']=="0" || @$row['is_facebook']==""){ echo "none"; } ?>;">
									   <div class="col-md-3"> </div>
										<div class="col-md-9">
											
											
                                            <?php
                                            $limit = 100;
                                            if(isset($_REQUEST['log']) && isset($_REQUEST['limit']) && $_REQUEST['limit']!="")
                                            {
                                                $limit = $_REQUEST['limit'];
                                            }
                                            
                                            $url="https://graph.facebook.com/me/accounts?$access_token&limit=$limit"; 
                                            $json=post_fb($url,"get");
                                            $pages=json_decode($json,true);
                                            if(isset($_REQUEST['log'])){
                                                echo "<pre>";
                                                print_r($pages);
                                                echo "</pre>";
                                            }
                                            ?>
                                            
											  <select class="form-control" id="fb_page" name="fb_page" onchange="getReviews(this)">
                                                <option value=""> Choose Facebook  Page/Business </option>
                                                <?php                                                  
                                                if(isset($pages['data']) && count($pages['data'])>0)
                                                {
                                                    foreach($pages['data'] as $page)
                                                    {
                                                        if(!in_array($page['id'],$fb_pages))
                                                        {
                                                        ?>
                                                        <option <?php if(@$row['fb_page'] == $page['id']){ echo "selected='selected'"; }?> value="<?php echo $page['id'];?>|<?php echo $page['name'];?>|<?php echo $page['access_token'];?>"><?php echo $page['name'];?> (<?php echo $page['id'];?>)</option>
                                                        <?php
                                                        }
                                                    }
                                                }
                                                ?>
                                                
											  </select>
                                              <span style="font-size:12px;font-weight: normal !important;color: #797979;">
                                                  ( List of your Facebook pages )
                                              </span>
										</div>
									</div>
                                    
                                    <div class="form-group">
										<label class="col-md-3 control-label" for="inputDefault">Google:</label>
										<div class="col-md-6">
                                            <input id="is_google" value="1" name="is_google" type="checkbox" onclick="showHidePlatform(this,'google')" <?php if(@$row['is_google']=="1"){ echo "checked"; } ?> />
                                            <label for="is_google"> Connent your Google Places / Business </label>
                                            <?php
                                            if(trim(@$settings['google_key'])==""){
                                            ?>
                                            <br /><span class="text-danger"><i class="fa fa-warning"></i> Google project key missing! Please add <a href="google_settings.php">here</a> to get Google place reviews</span>
                                            <?php
                                            }
                                            ?>
										</div>
									</div>
                                   
                                    <div class="form-group" id="g_area" style="display: <?php if(@$row['is_google']=="0" || @$row['is_google']==""){ echo "none"; } ?>;">
                                        <div class="col-md-3"> </div>
                                        <div class="col-md-9">
                                            <input class="form-control" name="google_business" id="google_business" value="<?php echo @$row['google_business'] ?>" type="text" placeholder="Enter Business / Place" />
                                            <input type="hidden" name="place_id" id="place_id" value="<?php echo @$row['place_id'] ?>" />
                                        </div>
                                    </div>
                                    
                                    <div class="form-group">
										<label class="col-md-3 control-label" for="inputDefault">Yelp:</label>
										<div class="col-md-6">
                                            <input id="is_yelp" value="1" name="is_yelp" type="checkbox" onclick="showHidePlatform(this,'yelp')" <?php if(@$row['is_yelp']=="1"){ echo "checked"; } ?> />
                                            <label for="is_yelp"> Connent your Yelp Business</label>
										</div>
									</div>
                                    
                                    <div class="form-group" id="y_area" style="display: <?php if(@$row['is_yelp']=="0" || @$row['is_yelp']==""){ echo "none"; } ?>;">
									    <div class="col-md-3"></div>
                                        <div class="col-md-8">
                                            <input class="form-control" name="yelp_business_id" id="yelp_business_id" value="<?php echo @$row['yelp_business_id'] ?>" type="text" placeholder="Enter Yelp Business ID" />
                                            <span id="yelp_error_area" class="text-danger"></span>
                                        </div>
                                        <div class="col-md-1" style="padding-left:0px;">
                                            <button class="btn btn-sm btn-default" type="button" onclick="getYelpReviews()"><i class="fa fa-repeat"></i></button>
                                        </div>
									</div>
                                    
                                    <div class="form-group">
										<label class="col-md-3 control-label" for="inputDefault">Custom:</label>
										<div class="col-md-6">
                                            <input id="is_custom" value="1" name="is_custom" type="checkbox" onclick="showHidePlatform(this,'custom')" <?php if(@$row['is_custom']=="1"){ echo "checked"; } ?> />
                                            <label for="is_custom"> Your Custom Reviews</label>
										</div>
									</div>
                                    
                                    <div class="form-group">
										<label class="col-md-3 control-label" for="inputDefault">Social Share:</label>
										<div class="col-md-6">
                                            <input id="is_social_share" value="1" name="is_social_share" type="checkbox" onclick="showHidePlatform(this,'social_share')" <?php if(@$row['is_social_share']=="1"){ echo "checked"; } ?> />
                                            <label for="is_social_share"> </label>
										</div>
									</div>
                                    
                                    <div id="social_share_area" style="display: <?php if(@$row['is_social_share']=="0" || @$row['is_social_share']==""){ echo "none"; } ?>;">
                                        
                                        <div class="form-group">
    										<label class="col-md-3 control-label" for="inputDefault"></label>
    										<div class="col-md-6">
                                                <input class="form-control" name="meta_title" id="meta_title" value="<?php echo @$row['meta_title'] ?>" type="text" placeholder="Enter Meta Title" />
    										</div>
    									</div>
                                        
                                        <div class="form-group">
    										<label class="col-md-3 control-label" for="inputDefault"></label>
    										<div class="col-md-6">
                                                <input class="form-control" name="meta_description" id="meta_description" value="<?php echo @$row['meta_description'] ?>" type="text"  placeholder="Enter Meta Description"/>
    										</div>
    									</div>
                                        
                                        <div class="form-group">
    										<label class="col-md-3 control-label" for="inputDefault"></label>
    										<div class="col-md-6">
                                                <input type="file" name="meta_picture" class="filestyle" data-buttontext="Choose File" data-buttonname="btn-default" data-placeholder="Enter Meta Picture" style="padding-left: 0;">
                                                <input type="hidden" name="hidden_meta_picture" id="hidden_meta_picture" value="<?php echo @$row['meta_picture'] ?>" />
                                                
                                                <?php
                                                if(@$row['meta_picture']!=""){
                                                    ?>
                                                    <img src="uploads/<?php echo $row['meta_picture']; ?>" />
                                                    <?php
                                                }
                                                ?>
    										</div>
    									</div>
                                        
                                    </div>
                                    
                                    <div class="row">
                                        <div class="col-md-12">
                                            <hr />
                                        </div>
                                    </div>
                                    
                                    <div class="">
									   <div class="col-md-4" style="padding-left:0px;">                                       
                                            <div id="settings_nav" style="display:<?php if(@$row['is_facebook']=="1" || @$row['is_google']=="1"){ echo ""; }else{ echo "none"; } ?>;">
                                                
                                                <ul class="nav nav-tabs tabs-bordered">
                                                    <li class="active">
                                                        <a href="#settings_tab" data-toggle="tab" aria-expanded="true">
                                                            <span class="visible-xs"><i class="fa fa-home"></i></span>
                                                            <span class="hidden-xs">Settings</span>
                                                        </a>
                                                    </li>
                                                    <li class="">
                                                        <a href="#embed_tab" data-toggle="tab" aria-expanded="false">
                                                            <span class="visible-xs"><i class="fa fa-user"></i></span>
                                                            <span class="hidden-xs">Embed Code</span>
                                                        </a>
                                                    </li>
                                                </ul>
                                                
                                                <div class="tab-content">
                                                    <div class="tab-pane active" id="settings_tab">
                                                        <div class="form-group">
                                                            <label class="col-md-12">Widget Style</label>
                                                            <div class="col-md-4">
                                                                <div class="radio-custom radio-success">
        															<input type="radio" name="style" id="list" value="list" onclick="changeStyle('list')" <?php if(@$row['style']=="list"){ echo "checked"; } ?> />
        															<label for="list">List</label>
        														</div>
                                                            </div>
                                                            <div class="col-md-4">
                                                                <div class="radio-custom radio-primary">
        															<input type="radio" name="style" id="grid" value="grid" onclick="changeStyle('grid')" <?php if(@$row['style']=="grid"){ echo "checked"; } ?> />
        															<label for="grid">Grid</label>
        														</div>
                                                            </div>
                                                            <div class="col-md-4">
        														<div class="radio-custom">
        															<input type="radio" name="style" id="slide" value="slide" onclick="changeStyle('slide')" <?php if(@$row['style']=="slide"){ echo "checked"; } ?>/>
        															<label for="slide">Slide</label>
        														</div>
                                                            </div>   
                                                        </div>
                                                        
                                                        <?php
                                                        /*
                                                        if($row['name_color']==NULL || $row['name_color']=="")
                                                            $row['name_color']="#1f739d";
                                                        if($row['rating_color']==NULL || $row['rating_color']=="")
                                                            $row['rating_color']="#eb995e";
                                                        if($row['date_color']==NULL || $row['date_color']=="")
                                                            $row['date_color']="#31620f";//777777
                                                        if($row['review_color']==NULL || $row['review_color']=="")
                                                            $row['review_color']="#4a0954";//7b7b7b
                                                        if($row['widget_bg_color']==NULL || $row['widget_bg_color']=="")
                                                            $row['widget_bg_color']="#f4fbf6";
                                                        if($row['widget_box_shadow']==NULL || $row['widget_box_shadow']=="")
                                                            $row['widget_box_shadow']="#66e89a";
                                                        */
                                                        ?>
                                                        
                                                        <div class="form-group">
            												<label class="col-md-12">Author Font Color</label>
            												<div class="col-md-12">
            													<input name="name_color" id="name_color" value="<?php echo @$row['name_color'] ?>" type="text" data-plugin-colorpicker class="colorpicker-default form-control"/>
            												</div>
            											</div>
                                                        
                                                        <div class="form-group">
            												<label class="col-md-12">Rating Color</label>
            												<div class="col-md-12">
            													<input name="rating_color" id="rating_color" value="<?php echo @$row['rating_color'] ?>" type="text" data-plugin-colorpicker class="colorpicker-default form-control"/>
            												</div>
            											</div>
                                                        
                                                        <div class="form-group">
            												<label class="col-md-12">Date Font Color</label>
            												<div class="col-md-12">
            													<input name="date_color" id="date_color" value="<?php echo @$row['date_color'] ?>" type="text" data-plugin-colorpicker class="colorpicker-default form-control"/>
            												</div>
            											</div>
                                                        
                                                        <div class="form-group">
            												<label class="col-md-12">Review Font Color</label>
            												<div class="col-md-12">
            													<input name="review_color" id="review_color" value="<?php echo @$row['review_color'] ?>" type="text" data-plugin-colorpicker class="colorpicker-default form-control"/>
            												</div>
            											</div>
                                                        
                                                        <div class="form-group">
            												<label class="col-md-12">Widget Background Color</label>
            												<div class="col-md-12">
            													<input name="widget_bg_color" id="widget_bg_color" value="<?php echo @$row['widget_bg_color'] ?>" type="text" data-plugin-colorpicker class="colorpicker-default form-control"/>
            												</div>
            											</div>
                                                                                                                
                                                        <div class="form-group">
            												<label class="col-md-12">Widget Box Shadow</label>
            												<div class="col-md-12">
            													<input name="widget_box_shadow" id="widget_box_shadow" value="<?php echo @$row['widget_box_shadow'] ?>" type="text" data-plugin-colorpicker class="colorpicker-default form-control"/>
            												</div>
            											</div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-md-9">Display Picture</label>
                                                            <div class="col-md-3">
                                                                <div class="checkbox-custom checkbox-default">
                                                                    <input type="checkbox" id="display_dp" name="display_dp" onclick="showHideThings(this,'dp')" <?php if(@$row['display_dp']=="1"){ echo "checked='checked'"; } ?> />
        															<label for=""></label>
        												        </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-md-9">Display Date</label>
                                                            <div class="col-md-3">
                                                                <div class="checkbox-custom checkbox-default">
                                                                    <input type="checkbox" id="display_date" name="display_date" onclick="showHideThings(this,'date')" <?php if(@$row['display_date']=="1"){ echo "checked='checked'"; } ?> />
        															<label for=""></label>
        												        </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-md-9">Display Rating</label>
                                                            <div class="col-md-3">
                                                                <div class="checkbox-custom checkbox-default">
                                                                    <input type="checkbox" id="display_rating" name="display_rating" onclick="showHideThings(this,'rating')" <?php if(@$row['display_rating']=="1"){ echo "checked='checked'"; } ?> />
        															<label for=""></label>
        												        </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                                                            <label class="col-md-9">Display Review</label>
                                                            <div class="col-md-3">
                                                                <div class="checkbox-custom checkbox-default">
                                                                    <input type="checkbox" id="display_review" name="display_review" onclick="showHideThings(this,'review')" <?php if(@$row['display_review']=="1"){ echo "checked='checked'"; } ?> />
        															<label for=""></label>
        												        </div>
                                                            </div>
                                                        </div>
                                                        
                                                        <div class="form-group">
                    										<label class="col-md-12" for="inputDefault">Font Size:</label>
                    										<div class="col-md-12">
                                                                <select name="font_size" id="font_size" data-plugin-selectTwo class="form-control populate" onchange="applyFont(this)">
                                                                    <option value="14px">Default</option>
                                                                    <?php
                                                                    for($i=8;$i<=26;$i++){
                                                                        ?>
                                                                        <option value="<?php echo $i; ?>px" <?php if(@$row['font_size']==$i."px"){ echo "selected"; } ?>><?php echo $i; ?>px</option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                    										</div>
                    									</div>
                                                        
                                                        <div class="form-group">
                    										<label class="col-md-12" for="inputDefault">Font Family:</label>
                    										<div class="col-md-12">
                                                                <select name="font_family" id="font_family" data-plugin-selectTwo class="form-control populate" onchange="applyFontFamily(this)">
                                                                    <option value="">Default</option>
                                                                    <?php
                                                                    foreach($fonts as $font){
                                                                    ?>
                                                                    <option value="<?php echo $font; ?>" <?php if(@$row['font_family']==$font){ echo "selected"; } ?>><?php echo $font; ?></option>
                                                                    <?php
                                                                    }
                                                                    ?>
                                                                </select>
                    										</div>
                    									</div>
                                                       
                                                        <div class="form-group">
                                                            <div class="col-md-12">
                                                                <input name="id" type="hidden" value="<?php echo @$_REQUEST['id'] ?>" />
                                                                <button class="btn btn-success" type="button" onclick="submitForm()"> Save Campaign</button>
                                                            </div>
                                                        </div>
                                                        
                                                    </div>
                                                    <div class="tab-pane" id="embed_tab">                                                       
                                                        <div class="form-group">
                                                            <label>Embed Code</label>
                                                            <?php 
                                                            $appURL = getServerURL();
                                                            $campID = base64_encode($_REQUEST['id']);
                                                            ?>
                                                            <textarea class="form-control code" style=" height: 290px;">
<script type="text/javascript">
var review_token = '<?php echo $campID; ?>';
var review_target = 'nm-review-container';
var application_url = '<?php echo $appURL; ?>'
</script>
<script src="<?php echo $appURL; ?>embed.js?v=5" type="text/javascript"></script>
<div id="nm-review-container"></div>
                                                            </textarea>
                                                        </div>
                                                        
                                                        
                                                        
                                                        <div class="form-group">
                                                            <label>IFrame Code</label>
                                                            <textarea class="form-control code" style=" height: 120px;"><iframe src="<?php echo $appURL; ?>reviews.php?id=<?php echo $campID; ?>" width="960" style="border:none;" height="800"></iframe></textarea>
                                                        </div>
                                                
                                                        <div class="form-group" id="social_share_btns" style="display: <?php if(@$row['is_social_share']=="0" || @$row['is_social_share']==""){ echo "none"; } ?>;">
                                                            <label>Share on</label>
                                                            <div class="button-list">       
                                                                <button type="button" class="btn btn-facebook waves-effect waves-light" onclick="socialShare('facebook')">
                                                                   <i class="fa fa-facebook m-r-5"></i> Facebook
                                                                </button>
                                                                
                                                                <button type="button" class="btn btn-googleplus waves-effect waves-light" onclick="socialShare('gplus')">
                                                                   <i class="fa fa-google-plus m-r-5"></i> Google+
                                                                </button>
                                                                
                                                                <button type="button" class="btn btn-twitter waves-effect waves-light" onclick="socialShare('twitter')">
                                                                   <i class="fa fa-twitter m-r-5"></i> Twitter
                                                                </button>
                                                                
                                                                <button type="button" class="btn btn-linkedin waves-effect waves-light" onclick="socialShare('linkedin')">
                                                                   <i class="fa fa-linkedin m-r-5"></i> Linkedin
                                                                </button>
                                                            </div>
                                                        </div>
                                                        
                                                        
<script language="javascript">
function socialShare(social)
{
    var share_url = '<?php echo urlencode($appURL."reviews.php?id=".$campID); ?>';
    if(social=="facebook"){
        var social_url = "https://www.facebook.com/sharer/sharer.php?u="+share_url;
    }else if(social=="twitter"){
        var social_url = "https://twitter.com/intent/tweet?url="+share_url;
    }else if(social=="linkedin"){
        var social_url = "http://www.linkedin.com/shareArticle?url="+share_url;
    }else if(social=="gplus"){
        var social_url = "https://plus.google.com/share?url="+share_url;
    }
    window.fb_share_box = window.open(social_url,"share-box",'width=572,height=567');
    return false;
}
function submitForm(){
    document.forms['campaign_form'].submit();
}                                                                                               
</script>
                                                        
                                                    </div>
                                                </div>
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                                
                                            </div>
                                            
                                       </div>
										<div class="col-md-8">
                                            <h3>Reviews Preview</h3>
                                            <div class="border m-b-20"></div>
											<div id="reviews_loader"></div>
                                            <div class="form-group" id="reviews"></div>
										</div>
									</div>
                                    	
								</form>
                                   
                                   
                                <ul class="media-list" id="list_structure" style="display: none;">
                                    <li class="media thumbnail">
                                        <a class="pull-left" href="_action_url_" target="_blank">
                                            <img class="media-object img-circle  r_dp" style="width:50px; height:50px;"
                                                 src="_picture_url_" alt=""/>
                                        </a>
                                        <div class="media-body">
                                            <h5 class="media-heading"><a href="_action_url_" target="_blank" class="r_name">_author_name_</a> <span class="user-rating r_rating">_rating_</span></h5>
                                            <h6 class="r_date">_date_</h6>
                                            <p class="r_review" align="justify">_review_</p>
                                        </div>
                                    </li>
                                </ul>
                                
                                <div class="row" id="grid_structure" style="display: none;">
                                    <div class="col-md-6">
                                        <div class="thumbnail">
                                            <img src="_picture_url_" class="img-responsive r_dp" alt=""/>
                                            <div class="caption" align="center">
                                                <h3><a href="_action_url_" target="_blank" class="r_name">_author_name_</a> <span class="user-rating r_rating">_rating_</span></h3>
                                                <h6 class="r_date">_date_</h6>
                                                <p class="r_review" align="justify">_review_</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                
                                <div class="row" id="slide_structure" style="display: none;">
									<div class="item _active_" align="center">
										<div class="row">
                                            <div class="col-md-12">
                                                <img src="_picture_url_" class="img-responsive r_dp" alt=""/>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-12">
        										<div class="carousel-caption" align="center">
        											<h3 class="font-600 r_name" align="center"><a href="_action_url_" target="_blank" class="r_name">_author_name_</a> <span class="user-rating r_rating">_rating_</span></h3>
        											<h6 class="r_date">_date_</h6>
                                                    <p class="r_review" align="center">_review_</p>
        										</div>
                                            </div>
                                        </div>
									</div>
                                </div>
                                
                                <div id="json_container_facebook" style="display:none;"><?php echo $facebook_json;?></div>
                                <div id="json_container_google" style="display:none;"><?php echo $google_json; ?></div>
                                <div id="json_container_yelp" style="display:none;"><?php echo $yelp_json;?></div>
                                <div id="json_container_custom" style="display:none;"><?php echo $custom_json;?></div>
                                
                                </div>
                            </section>
                        </div>
                    </div>
                </section>
                
              </div>
        </section>

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
		<script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
		
		<!-- Specific Page Vendor -->
        <script src="assets/vendor/jquery-ui/js/jquery-ui-1.10.4.custom.js"></script>
		<script src="assets/vendor/jquery-autosize/jquery.autosize.js"></script>
		<script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
        
        <script src="assets/vendor/ios7-switch/ios7-switch.js"></script>
		<script src="assets/vendor/bootstrap-colorpicker/js/bootstrap-colorpicker.js"></script>
        <script src="assets/vendor/select2/select2.js"></script>
        <script src="assets/vendor/bootstrap-multiselect/bootstrap-multiselect.js"></script>
        
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>



<script>

function showHidePlatform(obj,platform){
    if(platform=="facebook"){
        if($(obj).is(":checked")){
            $("#f_area").slideDown();
        }else{
            $("#f_area").slideUp();
            $("#json_container_facebook").text("");
            $("#fb_page").val("");
        }
    }else if(platform=="google"){
        if($(obj).is(":checked")){
            $("#g_area").slideDown();
        }else{
            $("#g_area").slideUp();
            $("#json_container_google").text("");
            $("#google_business").val("");
        }
    }else if(platform=="yelp"){
        if($(obj).is(":checked")){
            $("#y_area").slideDown();
        }else{
            $("#y_area").slideUp();
            $("#json_container_yelp").text("");
            $("#yelp_business_id").val("");
        }
    }else if(platform=="custom"){
        if($(obj).is(":checked")){
            getcustomReviews();
        }else{
            $("#json_container_custom").text("");
        }
    }else if(platform=="social_share"){
        if($(obj).is(":checked")){
            $("#social_share_area").slideDown();
            $("#social_share_btns").slideDown();
        }else{
            $("#social_share_area").slideUp();
            $("#social_share_btns").slideUp();
        }
    }
    changeStyle($("input[name='style']:checked").val());
}

function showHideThings(obj,thing){
    if($(obj).is(":checked")){
        $(".r_"+thing).css("display","");
    }else{
        $(".r_"+thing).css("display","none");
    }
    
}

function changeMenu(bit){
    if(bit=="facebook"){
        $("#f_area").show();
        $("#g_area").hide();
        $("#social_type").val(1);
        $("#f_btn").removeClass("btn-default");
        $("#f_btn").addClass("btn-inverse");
        $("#g_btn").removeClass("btn-inverse");
        $("#g_btn").addClass("btn-default");
        
    }else{
        $("#f_area").hide();
        $("#g_area").show();
        $("#social_type").val(2);
        $("#g_btn").removeClass("btn-default");
        $("#g_btn").addClass("btn-inverse");
        $("#f_btn").removeClass("btn-inverse");
        $("#f_btn").addClass("btn-default");
    }
    //resetSettings();
        
}

function resetSettings(){
    $("#reviews").html("");
    $("#settings_nav").slideUp("slow");
    $("#fb_page").val("");
    $("#google_business").val("");
}


function changeStyle(style="list"){
    
    
    $( "#reviews" ).html("");
    
    if(style=="slide"){
        var content = '<div id="carousel-example-captions" data-ride="carousel" class="carousel slide"><div role="listbox" class="carousel-inner"></div><a href="#carousel-example-captions" role="button" data-slide="prev" class="left carousel-control"> <span aria-hidden="true" class="fa fa-angle-left"></span> <span class="sr-only">Previous</span> </a><a href="#carousel-example-captions" role="button" data-slide="next" class="right carousel-control"> <span aria-hidden="true" class="fa fa-angle-right"></span> <span class="sr-only">Next</span></a></div>';
    }else{
        var content = '<ul class="media-list"></ul>';
    }
    
    $( "#reviews" ).html( content );
    
    if($("#is_google").is(":checked")){
        var json = $("#json_container_google").text();
        if(json.trim()!=""){
            showReviews(json,"google",style);
        }
    }
    
    if($("#is_facebook").is(":checked")){
        var json = $("#json_container_facebook").text();
        if(json.trim()!=""){
            showReviews(json,"facebook",style);
        }
    }
    
    if($("#is_yelp").is(":checked")){
        var json = $("#json_container_yelp").text();
        if(json.trim()!=""){
            showReviews(json,"yelp",style);
        }
    }
    
    if($("#is_custom").is(":checked")){
        var json = $("#json_container_custom").text();
        if(json.trim()!=""){
            showReviews(json,"custom",style);
        }
    }
    
    addRating();
    
    if(style=="slide"){
        $("#reviews .item:first-child").addClass("active");
    }
}

function showReviews(json,platform,style="list"){
    
    var response = jQuery.parseJSON(json);
    if(platform=="google"){
        if(typeof(response.error_message) != "undefined" && response.error_message !== null) {
            var alertmsg = '<div class="alert alert-danger" style="margin: 10px -7px;"><b>Google API ERROR</b><br /> '+response.status+' : '+response.error_message+'</div>';
            $(".content-page .container").prepend(alertmsg);
        }
        else
        if(typeof(response.result.reviews) != "undefined" && response.result.reviews !== null) {       
           
            $.each( response.result.reviews, function( key, review ) {
                var action_url = review.author_url;
                var picture_url = review.profile_photo_url;
                var author_name = review.author_name;
                var rating = review.rating;
                var date = review.relative_time_description;
                var review = review.text;

                if(style=="list"){
                    var structure = $("#list_structure").html();
                }else if(style=="grid"){
                    var structure = $("#grid_structure").html();
                }else{
                    var structure = $("#slide_structure").html();
                }
                structure = structure.replace(/_action_url_/g, action_url);
                structure = structure.replace(/_picture_url_/g, picture_url);
                structure = structure.replace(/_author_name_/g, author_name);
                structure = structure.replace(/_rating_/g, rating);
                structure = structure.replace(/_date_/g, date);
                structure = structure.replace(/_review_/g, review);
                
                if(style=="slide"){
                    $("#reviews .carousel-inner").append(structure);
                }else{
                    $("#reviews ul").append(structure);
                }
                
            });
            //addRating();
            $("#settings_nav").slideDown("slow");  
        }
        else{
            $("#reviews").append("No Google Reviews Found");
        }
    }
    else
    if(platform=="facebook"){
        if(typeof(response.data) != "undefined" && response.data !== null) {       
            
            $.each( response.data, function( key, review ) {
                var action_url = review.open_graph_story.id;
                var picture_url = "https://graph.facebook.com/"+review.reviewer.id+"/picture?type=large";
                var author_name = review.reviewer.name;
                var rating = review.rating;
                var date = review.created_time;
                var review = review.review_text;

                if(style=="list"){
                    var structure = $("#list_structure").html();
                }else if(style=="grid"){
                    var structure = $("#grid_structure").html();
                }else{
                    var structure = $("#slide_structure").html();
                }
                structure = structure.replace(/_action_url_/g, action_url);
                structure = structure.replace(/_picture_url_/g, picture_url);
                structure = structure.replace(/_author_name_/g, author_name);
                structure = structure.replace(/_rating_/g, rating);
                structure = structure.replace(/_date_/g, date);
                structure = structure.replace(/_review_/g, review);
                
                if(style=="slide"){
                    $("#reviews .carousel-inner").append(structure);
                }else{
                    $("#reviews ul").append(structure);
                }
            });
            //addRating();
            $("#settings_nav").slideDown("slow");  
        }
        else{
            $("#reviews").append("No Facebook Reviews Found");
        }
    }
    else
    if(platform=="yelp"){
        if(typeof(response.error) != "undefined" && response.error !== null) {
            console.log("ererer");
            $("#yelp_error_area").html(response.error.description);
        }
        else
        if(typeof(response.reviews) != "undefined" && response.reviews !== null) {       
            $("#yelp_error_area").html("");
            $.each( response.reviews, function( key, review ) {
                var action_url = review.url;
                var picture_url = review.user.image_url;
                var author_name = review.user.name;
                var rating = review.rating;
                var date = review.time_created;
                var review = review.text;

                if(style=="list"){
                    var structure = $("#list_structure").html();
                }else if(style=="grid"){
                    var structure = $("#grid_structure").html();
                }else{
                    var structure = $("#slide_structure").html();
                }
                structure = structure.replace(/_action_url_/g, action_url);
                structure = structure.replace(/_picture_url_/g, picture_url);
                structure = structure.replace(/_author_name_/g, author_name);
                structure = structure.replace(/_rating_/g, rating);
                structure = structure.replace(/_date_/g, date);
                structure = structure.replace(/_review_/g, review);
                
                if(style=="slide"){
                    $("#reviews .carousel-inner").append(structure);
                }else{
                    $("#reviews ul").append(structure);
                }
            });
            //addRating();
            $("#settings_nav").slideDown("slow");  
        }
        else{
            $("#reviews").append("No Facebook Reviews Found");
        }
    }
    else
    if(platform=="custom"){
        if(typeof(response.data) != "undefined" && response.status == "success") {       
            
            $.each( response.data, function( key, review ) {
                var action_url = "#";
                var picture_url = review.photo;
                var author_name = review.name;
                var rating = review.rating;
                var date = review.date;
                var review = review.review;

                if(style=="list"){
                    var structure = $("#list_structure").html();
                }else if(style=="grid"){
                    var structure = $("#grid_structure").html();
                }else{
                    var structure = $("#slide_structure").html();
                }
                structure = structure.replace(/_action_url_/g, action_url);
                structure = structure.replace(/_picture_url_/g, picture_url);
                structure = structure.replace(/_author_name_/g, author_name);
                structure = structure.replace(/_rating_/g, rating);
                structure = structure.replace(/_date_/g, date);
                structure = structure.replace(/_review_/g, review);
                
                if(style=="slide"){
                    $("#reviews .carousel-inner").append(structure);
                }else{
                    $("#reviews ul").append(structure);
                }
            });
            //addRating();
            $("#settings_nav").slideDown("slow");  
        }
        else{
            $("#reviews").append("No Custom Reviews Found");
        }
    }
    
        
    
    
    
    
    
    
}

function initMap() {    
    
    var map = new google.maps.Map(document.getElementById('map'), {
      center: {lat: -33.8688, lng: 151.2195},
      zoom: 13
    });
    
    var input = document.getElementById('google_business');
    var autocomplete = new google.maps.places.Autocomplete(input);
    autocomplete.bindTo('bounds', map);
    
    autocomplete.addListener('place_changed', function() {
      $( "#reviews" ).prepend("<center class='m-t-50'><img src='assets/img/ajax-loader-black-bar.gif'/></center>");
      var place = autocomplete.getPlace();
      if (!place.geometry) {
        return;
      }
      
      $("#place_id").val(place.place_id);
      var qry = "action=place_reviews&place_id="+place.place_id;
      $.post( "action.php",qry, function( data ) {
        
          $("#json_container_google").text(data);
          changeStyle($("input[name='style']:checked").val());
        
      });
      
      
    });
}
</script>
<?php
if(@$settings['google_key']!=""){
?>    
<script src="https://maps.googleapis.com/maps/api/js?key=<?php echo @$settings['google_key'];?>&libraries=places&callback=initMap"
async defer></script>
<?php
}
?>

<?php
function post_fb($url,$method,$body="",$apiKey=""){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url );
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.8.1.13) Gecko/20080311 Firefox/2.0.0.13');
    if($apiKey!=""){
        $headr[] = 'Authorization: Bearer '.$apiKey;
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headr);
    }
    if($method == "post"){
        curl_setopt($ch, CURLOPT_POST, true );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    else{
        //curl_setopt($ch, CURLOPT_HTTPGET, true );   
    }   
    $res = curl_exec($ch);
    //echo curl_error($ch);
    return $res;
}


function post_fb2 (){
    $curl = curl_init();

    curl_setopt_array($curl, array(
      CURLOPT_URL => "https://reviews.socialspider.net/review_api.php?uid=1",
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_ENCODING => "",
      CURLOPT_MAXREDIRS => 10,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
      CURLOPT_CUSTOMREQUEST => "GET",
      CURLOPT_HTTPHEADER => array(
        "cache-control: no-cache"
      ),
    ));
    
    $response = curl_exec($curl);
    $err = curl_error($curl);
    
    curl_close($curl);
    
    if ($err) {
      echo "cURL Error #:" . $err;
    } else {
      echo $response;
    }
}



?>
        
        
        
        <!-- Rating js -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
        
        
        <script>
            
            
            
            $( document ).ready(function() {
                 <?php
                 if($row['is_google']==1 || $row['is_facebook']==1 || $row['is_yelp']==1 || $row['is_custom']==1)
                 {
                    ?>
                    changeStyle($("input[name='style']:checked").val());
                    ApplyStyle();
                    <?php
                 }
                 ?>
            });
            
            
        function ApplyStyle(){
            $(".r_name").css("color",$('#name_color').val());
            $(".r_date").css("color",$('#date_color').val());
            $(".r_review").css("color",$('#review_color').val());
            $(".user-rating").css("color",$('#rating_color').val());
            
            $(".thumbnail").css("background",$('#widget_bg_color').val());
            $(".carousel-inner .item").css("background",$('#widget_bg_color').val());
            $("#slide_structure .item").css("background",$('#widget_bg_color').val());
            
            $(".thumbnail").css("box-shadow","0 2px 5px "+$("#widget_box_shadow").val()+", 0 2px 10px rgba(0, 0, 0, 0)");
            
            $(".r_review").css("font-family",$("#font_family").val());
            $(".r_review").css("font-size",$("#font_size").val());
            
            if($("#display_dp").is(":checked")){
                $(".r_dp").css("display","");
            }else{
                $(".r_dp").css("display","none");
            }
            
            if($("#display_rating").is(":checked")){
                $(".r_rating").css("display","");
            }else{
                $(".r_rating").css("display","none");
            }
            
            if($("#display_date").is(":checked")){
                $(".r_date").css("display","");
            }else{
                $(".r_date").css("display","none");
            }
            
            if($("#display_review").is(":checked")){
                $(".r_review").css("display","");
            }else{
                $(".r_review").css("display","none");
            }
        }    
        </script>
        
        <script>
            
            $('#widget_bg_color').colorpicker({format: 'hex'}).on('changeColor', function(ev){
                $(".thumbnail").css("background",ev.color.toHex());
                $(".carousel-inner .item").css("background",ev.color.toHex());
                $("#slide_structure .item").css("background",ev.color.toHex());
            });
            
            $('#widget_box_shadow').colorpicker({format: 'hex'}).on('changeColor', function(ev){
                $(".thumbnail").css("box-shadow","0 2px 5px "+ev.color.toHex()+", 0 2px 10px rgba(0, 0, 0, 0)");
                $(".carousel slide").css("box-shadow","0 2px 5px "+ev.color.toHex()+", 0 2px 10px rgba(0, 0, 0, 0)");
                
            });
            
            $('#name_color').colorpicker({format: 'hex'}).on('changeColor', function(ev){
                $(".r_name").css("color",ev.color.toHex());
            });
            
            $('#date_color').colorpicker({format: 'hex'}).on('changeColor', function(ev){
                $(".r_date").css("color",ev.color.toHex());
            });
            
            $('#review_color').colorpicker({format: 'hex'}).on('changeColor', function(ev){
                $(".r_review").css("color",ev.color.toHex());
            });
            
            $('#rating_color').colorpicker({format: 'hex'}).on('changeColor', function(ev){
                $(".user-rating").rateYo("option", "ratedFill", ev.color.toHex());
            });
            
        </script>

        
        <?php
        function getServerURL()
        {
            $serverName = $_SERVER['SERVER_NAME'];
            $filePath = $_SERVER['REQUEST_URI'];
            $withInstall = substr($filePath,0,strrpos($filePath,'/')+1);
            $serverPath = $serverName.$withInstall;
            $applicationPath = $serverPath;
            
            if(strpos($applicationPath,'http://www.')===false)
            {
            if(strpos($applicationPath,'www.')===false)
            $applicationPath = 'www.'.$applicationPath;
            if(strpos($applicationPath,'http://')===false)
            $applicationPath = 'http://'.$applicationPath;
            }
            
            if(isset($_SERVER["HTTPS"])){
                $protocol = "https://";
            }else{
                $protocol = "http://";
            }
            
            $applicationPath = str_replace("www.","",$applicationPath);
            $applicationPath = str_replace("http://",$protocol,$applicationPath);
            $applicationPath = str_replace("https://",$protocol,$applicationPath);
                
            return $applicationPath;
        } 
        ?>
     
	</body>
</html>