<?php
include_once("header.php");
include_once("sidebar.php");

?>
<link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
          <section role="main" class="content-body">
					<header class="page-header">
						<h2>Plans Add / Edit</h2>
					
						<div class="right-wrapper pull-right" style="display:none;">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Tables</span></li>
								<li><span>Advanced</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>
                    
                    <div class="row">
						<div class="col-lg-12">
							<section class="panel">
								<div class="panel-body">
                                
                                    <div class="row">
                                        <div class="col-sm-12">
            								<h2 class="h2 mt-none mb-sm text-dark text-bold">
                                                Plans
                                            </h2>
            								<p class="text-muted font-13 m-b-15">                                            
                                                <!-- Description Goes Here <br /> -->
                                                &nbsp;
                                            </p>
            							</div>
                                        
                                        
                                        <?php
                                        if(isset($_SESSION['msg']) && $_SESSION['msg']!=""){
                                            ?>
                                            <div class="col-sm-12">
                                                <div class="alert alert-info"><?php echo $_SESSION['msg']; ?></div>
                                            </div>
                                            <?php
                                            unset($_SESSION['msg']);
                                        }
                                        ?>
                                    </div>
                                    <?php
        							$sql = "SELECT * FROM `plans` where id = '".@$_REQUEST['id']."'";
        							$result = $conn->query($sql);
        							$row = $result->fetch_assoc();
        							?>
                                    <form action="action.php?action=plans" method="post" class="form-horizontal form-bordered">
    									
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Title</label>
											<div class="col-md-6">
                                                <input class="form-control" name="title" value="<?php echo @$row['title'] ?>" type="text">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Description</label>
											<div class="col-md-6">
                                                <input class="form-control" name="description" value="<?php echo @$row['description'] ?>" type="text">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault"># of campaigns</label>
											<div class="col-md-6">
                                                <input class="form-control" name="no_of_campaigns" value="<?php echo @$row['no_of_campaigns'] ?>" type="text">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Amount</label>
											<div class="col-md-6">
                                                <input class="form-control" name="amount" value="<?php echo @$row['amount'] ?>" type="text">
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault"></label>
											<div class="col-md-6">
                                                <input type="hidden" name="id" value="<?php echo @$row['id']; ?>">
    											<button type="submit" name="submit" value="submit"  class="btn  btn-fill btn-success "><span class="ace-icon fa fa-save bigger-120"></span> Save</button>
											</div>
										</div>
                                        
    								</form>
                                </div>
                            </div>
                        </div>


                    </div> <!-- container -->

                </div> <!-- content -->

                <?php include_once("footer.php"); ?>

            </div>

        </div>
        <!-- END wrapper -->


<?php
function post_fb($url,$method,$body=""){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url );
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 100);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if($method == "post"){
        curl_setopt($ch, CURLOPT_POST, true );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    else{
        curl_setopt($ch, CURLOPT_HTTPGET, true );   
    }   
    return curl_exec($ch);
}
?>

        <script>
            var resizefunc = [];
        </script>

        <!-- jQuery  -->
        <script src="assets/js/detect.js"></script>
        <script src="assets/js/fastclick.js"></script>
        <script src="assets/js/jquery.blockUI.js"></script>
        <script src="assets/js/waves.js"></script>
        <script src="assets/js/jquery.slimscroll.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="../plugins/switchery/switchery.min.js"></script>

        <script src="../plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="../plugins/datatables/dataTables.bootstrap.js"></script>

        <script src="../plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="../plugins/datatables/buttons.bootstrap.min.js"></script>
        <script src="../plugins/datatables/jszip.min.js"></script>
        <script src="../plugins/datatables/pdfmake.min.js"></script>
        <script src="../plugins/datatables/vfs_fonts.js"></script>
        <script src="../plugins/datatables/buttons.html5.min.js"></script>
        <script src="../plugins/datatables/buttons.print.min.js"></script>
        <script src="../plugins/datatables/dataTables.fixedHeader.min.js"></script>
        <script src="../plugins/datatables/dataTables.keyTable.min.js"></script>
        <script src="../plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="../plugins/datatables/responsive.bootstrap.min.js"></script>
        <script src="../plugins/datatables/dataTables.scroller.min.js"></script>
        <script src="../plugins/datatables/dataTables.colVis.js"></script>
        <script src="../plugins/datatables/dataTables.fixedColumns.min.js"></script>
        
        <!-- init -->
        <script src="assets/pages/jquery.datatables.init.js"></script>

        <!-- App js -->
        <script src="assets/js/jquery.core.js"></script>
        <script src="assets/js/jquery.app.js"></script>
        
        <script type="text/javascript">
            $(document).ready(function () {
                $('#datatable-responsive').DataTable();
            });
            TableManageButtons.init();

        </script>

    </body>
</html>