<?php
@session_start();
include_once("database.php");
$uid = @$_REQUEST['uid'];
?>
<!DOCTYPE HTML>
<html>
<head>
<title>Pricing Plans</title>

<!-- App css -->
<link href="assets/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
<link href="assets/css/core.css" rel="stylesheet" type="text/css" />
<link href="assets/css/components.css" rel="stylesheet" type="text/css" />
<link href="assets/css/icons.css" rel="stylesheet" type="text/css" />
<link href="assets/css/pages.css" rel="stylesheet" type="text/css" />
<link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
<link href="assets/css/responsive.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="plugins/switchery/switchery.min.css" />



</head>
<body>


    <div class="row">
                            <div class="col-lg-9 center-page">
                                <div class="text-center">
                                    <h3 class="m-b-30 m-t-20">Sign up</h3>
                                    <p>
                                        Register your self today!
                                    </p>
                                </div>

                                <div class="row m-t-50">



		<?php        
        if(isset($_SESSION['message']) && trim($_SESSION['message'])!=''){
			echo $_SESSION['message'];
		}
		unset($_SESSION['message']);
        ?>
		
			<?php
				
                $sql = "select * from plans";
                $res = mysqli_query($con,$sql);
				$totalRecords = mysqli_num_rows($res);
				if($totalRecords>0){	
					while($row = mysqli_fetch_assoc($res)){
			?>
                <article class="pricing-column col-lg-4 col-md-4">
                    <div class="inner-box card-box">
                        <div class="plan-header text-center">
                            <h3 class="plan-title"><?php echo strtoupper($row['title'])?></h3>
                            <h2 class="plan-price">$ <?php echo $row['amount'];?></h2>
                            <div class="plan-duration">Per Month</div>
                        </div>
                        <ul class="plan-stats list-unstyled text-center">
                            <li><?php echo $row['description']; ?></li>
                            <li><?php echo $row['no_of_campaigns']?> No of campaigns</li>
                            <li>24x7 Support</li>
                        </ul>

                        <div class="text-center">
                            <a href="add_user.php?pid=<?php echo encode($row['id'])?>&uid=<?php echo $uid?>" class="btn btn-danger btn-bordred btn-rounded waves-effect waves-light">Signup Now</a>
                        </div>
                    </div>
                </article>
            <?php
            /*
			<div class="<?php echo $mainClass?>"<?php echo $margin?>>
				<div class="price-value <?php echo $index?>">
					<h2><a href="#"> <?php echo strtoupper($row['title'])?> </a></h2>
					<h5><span>$ <?php echo $row['amount'];?></span>
						<lable> / month</lable>
					</h5>
					<div class="<?php echo $saleBox?>"> <span class="on_sale title_shop">NEW</span> </div>
				</div>
				<div class="price-bg">
					<ul>
						<!-- <li class="whyt"><a href="#">Available SMS Credits <b><?php echo $row['sms_credits']?></b></a></li>-->
						<li><a href="#">Allowed No of campaigns <b><?php echo $row['no_of_campaigns']?></b></a></li>
						<li class="whyt"><a href="#">Description <b><?php echo $row['description']; ?></b></a></li>
						<li><a href="#">Secure Payment via Paypal</b></a></li>
						<li class="whyt"><a href="#">24/7 Support</a></li>
					</ul>
                    <div class="<?php echo $cart?>"> <a class="popup-with-zoom-anim" href="add_user.php?pid=<?php echo encode($row['id'])?>&uid=<?php echo $uid?>">Purchase</a> </div><br>
				</div>
			</div>
            */
            ?>
			<?php
					}
				}else{
					echo '<h1 style="color:red">No plans created by admin.</h1>';
				}
			?>
            </div>
        </div>
   </div>
			
		
		

<div class="footer">
	<div class="wrap">
		<p>&copy; 2016  All rights  Reserved | Powered by &nbsp;<a href="http://ranksol.com">Ranksol</a></p>
	</div>
</div>
</body>
</html>

<?php
function encode($str){
		$id=uniqid();
		$last=substr($id,strlen($id)-10);
		$start=rand(11,99);
		return $start.$str.$last;    
	}
?>