<?php
echo "<center><h1>New Update Server";
?>