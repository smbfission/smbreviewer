<?php
	include_once("database.php");
    
	if($_REQUEST['txn_type']=='subscr_payment'){
		$webUserID = $_REQUEST['custom'];
		$sql = "select * from web_user_info where id='".$webUserID."'";
		$res = mysqli_query($link,$sql);
		if(mysqli_num_rows($res)==0){
			$row = mysqli_fetch_assoc($res);
			$sel = "select * from user where email='".$row['email']."'";
			$exe = mysqli_query($link,$sel);
			if(mysqli_num_rows($exe)==0){
				
				$appUrl		 = getServerURL();
				$password	 = $row['password'];
				$ins = "insert into user
                       (name,email,password,type,response,response_code,subscription_id,paypal_subscriber_id)values
                       ('".$row['name']."','".$row['email']."','".$row['password']."','2','".$row['response']."','".$row['response_code']."','".$row['subscription_id']."','".$_REQUEST['subscr_id']."')";
				$exe = mysqli_query($link,$ins);
				if($exe){
					$userID	= mysqli_insert_id($link);
					mysqli_query($link,"delete from web_user_info where id='".$row['id']."'");
					
					$today	= date('Y-m-d H').':00:00';
					$endDate= date('Y-m-d H:i',strtotime('+1 month'.$today));
					
					// User notification
					$subject = "Successfully Signup!";
					$to		 = $row['email'];
					$from	 = 'admin@'.$_SERVER['SERVER_NAME'];
					$msg	 = "Congratulations %name%! <br /><br />You are successfully signup! <br /><br /> Please login below <br /><br /> %login_url%  <br /> %login_email% <br /> %login_pass% ";
					$msg	 = str_replace('%name%',$row['name'],$msg);
					$msg	 = str_replace('%login_email%',$row['email'],$msg);
					$msg	 = str_replace('%login_pass%',$password,$msg);
					$msg	 = str_replace('%login_url%',$appUrl,$msg);
					$FullName= 'Admin';
					sendEmail($subject,$to,$from,$msg,$FullName);
					
					// Admin notification
					$subject = "Successfully Signup!";
					$to		 = $appSettings['admin_email'];
					$from	 = 'admin@'.$_SERVER['SERVER_NAME'];
                    $msg     = "New user is signup";
					$msg	 = str_replace('%email%',$row['email'],$msg);
					$FullName= 'Admin';
					sendEmail($subject,$to,$from,$msg,$FullName);
				}
			}
		}else{ // existing user
			
			$payment_processor = 1;
			$sql = "select id,email from user where paypal_subscriber_id='".$_REQUEST['subscr_id']."'";
			
			
			$res = mysqli_query($link,$sql);
			if(mysqli_num_rows($res)){
				$row = mysqli_fetch_assoc($res);
				$userID = $row['id'];
				$appSettings = getAppSettings($userID);
				if(($_REQUEST['payment_status']=='Completed') ||  ($_REQUEST['payment_status']=='1')){
					$today	= date('Y-m-d H').':00:00';
					$endDate= date('Y-m-d H:i',strtotime('+1 month'.$today));
					
                    
					$subject = $appSettings['success_payment_email_subject'];
					$to		 = $row['email'];
					$from	 = 'admin@'.$_SERVER['SERVER_NAME'];
					$msg	 = $appSettings['success_payment_email'];
					$FullName= 'Admin';
					sendEmail($subject,$to,$from,$msg,$FullName);
					
					// Admin notification
					$appSettings = getAppSettings($userID,true);
					$subject = $appSettings['payment_noti_subject'];
					$to		 = $appSettings['admin_email'];
					$from	 = 'admin@'.$_SERVER['SERVER_NAME'];
					$msg	 = str_replace('%email%',$row['email'],$appSettings['payment_noti_email']);
					$FullName= 'Admin';
					sendEmail($subject,$to,$from,$msg,$FullName);
					
				}else{ // Payment failed
					$subject = $appSettings['failed_payment_email_subject'];
					$to		 = $row['email'];
					$from	 = 'admin@'.$_SERVER['SERVER_NAME'];
					$msg	 = $appSettings['failed_payment_email'];
					$FullName= 'Admin';
					sendEmail($subject,$to,$from,$msg,$FullName);
					
					// Admin notification
					$appSettings = getAppSettings($userID,true);
					$subject = $appSettings['payment_noti_subject'];
					$to		 = $appSettings['admin_email'];
					$from	 = 'admin@'.$_SERVER['SERVER_NAME'];
					$msg	 = str_replace('%email%',$row['email'],$appSettings['payment_noti_email']);
					$FullName= 'Admin';
					sendEmail($subject,$to,$from,$msg.'. Payment status is '.$_REQUEST['payment_status'],$FullName);
				}
			}
		}
        
		mysqli_query($link,
		"insert into payment_history	(business_email,payer_status,payer_email,txn_id,payment_status,gross_payment,product_name,user_id)values
        ('".$_REQUEST['business']."','".$_REQUEST['payer_status']."','".$_REQUEST['payer_email']."','".$_REQUEST['txn_id']."','".$_REQUEST['payment_status']."','".$_REQUEST['payment_gross']."','".$_REQUEST['item_name']."','1')");
	}
    
    
function getServerURL()
{
	$serverName = $_SERVER['SERVER_NAME'];
	$filePath = $_SERVER['REQUEST_URI'];
	$withInstall = substr($filePath,0,strrpos($filePath,'/')+1);
	$serverPath = $serverName.$withInstall;
	$applicationPath = $serverPath;
	
	if(strpos($applicationPath,'http://www.')===false)
	{
		if(strpos($applicationPath,'www.')===false)
			$applicationPath = 'www.'.$applicationPath;
		if(strpos($applicationPath,'http://')===false)
			$applicationPath = 'http://'.$applicationPath;
	}
	return $applicationPath;
}
?>