<?php
$json = '{
  "reviews": [
    {
      "id": "xAG4O7l-t1ubbwVAlPnDKg",
      "rating": 5,
      "user": {
        "id": "W8UK02IDdRS2GL_66fuq6w",
        "profile_url": "https://www.yelp.com/user_details?userid=W8UK02IDdRS2GL_66fuq6w",
        "image_url": "https://s3-media3.fl.yelpcdn.com/photo/iwoAD12zkONZxJ94ChAaMg/o.jpg",
        "name": "Ella A."
      },
      "text": "Went back again to this place since the last time i visited the bay area 5 months ago, and nothing has changed. Still the sketchy Mission, Still the cashier...",
      "time_created": "2016-08-29 00:41:13",
      "url": "https://www.yelp.com/biz/la-palma-mexicatessen-san-francisco?hrid=hp8hAJ-AnlpqxCCu7kyCWA&adjust_creative=0sidDfoTIHle5vvHEBvF0w&utm_campaign=yelp_api_v3&utm_medium=api_v3_business_reviews&utm_source=0sidDfoTIHle5vvHEBvF0w"
    },
    {
      "id": "1JNmYjJXr9ZbsfZUAgkeXQ",
      "rating": 4,
      "user": {
        "id": "rk-MwIUejOj6LWFkBwZ98Q",
        "profile_url": "https://www.yelp.com/user_details?userid=rk-MwIUejOj6LWFkBwZ98Q",
        "image_url": null,
        "name": "Yanni L."
      },
      "text": "The \"restaurant\" is inside a small deli so there is no sit down area. Just grab and go.\n\nInside, they sell individually packaged ingredients so that you can...",
      "time_created": "2016-09-28 08:55:29",
      "url": "https://www.yelp.com/biz/la-palma-mexicatessen-san-francisco?hrid=fj87uymFDJbq0Cy5hXTHIA&adjust_creative=0sidDfoTIHle5vvHEBvF0w&utm_campaign=yelp_api_v3&utm_medium=api_v3_business_reviews&utm_source=0sidDfoTIHle5vvHEBvF0w"
    },
    {
      "id": "SIoiwwVRH6R2s2ipFfs4Ww",
      "rating": 4,
      "user": {
        "id": "rpOyqD_893cqmDAtJLbdog",
        "profile_url": "https://www.yelp.com/user_details?userid=rpOyqD_893cqmDAtJLbdog",
        "image_url": null,
        "name": "Suavecito M."
      },
      "text": "Dear Mission District,\n\nI miss you and your many delicious late night food establishments and vibrant atmosphere.  I miss the way you sound and smell on a...",
      "time_created": "2016-08-10 07:56:44",
      "url": "https://www.yelp.com/biz/la-palma-mexicatessen-san-francisco?hrid=m_tnQox9jqWeIrU87sN-IQ&adjust_creative=0sidDfoTIHle5vvHEBvF0w&utm_campaign=yelp_api_v3&utm_medium=api_v3_business_reviews&utm_source=0sidDfoTIHle5vvHEBvF0w"
    }
  ],
  "total": 3,
  "possible_languages": ["en"]
}';

$yelp_reviews = json_decode($json,true);

echo "<pre>";
print_r($yelp_reviews);
if($yelp_reviews['total']>0){
    if(isset($yelp_reviews['reviews'])){
        foreach($yelp_reviews['reviews'] as $reviews){
            
            $action_url = $reviews['url'];
            $picture_url = $reviews['user']['image_url'];
            $author_name = $reviews['user']['name'];
            $rating = $reviews['rating'];
            $date = $reviews['time_created'];
            $review = $reviews['text'];
            
        }
    }
}

die();

?>