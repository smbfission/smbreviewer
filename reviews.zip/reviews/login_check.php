<?php
include("database.php");
if(isset($_POST['submit'])){
    if(empty($_POST['email']) || empty($_POST['password'])){
        $_SESSION['msg'] = "Plase fill the details";
        header("Location:index.php");
    }else{
        $email = $_POST['email'];
        $password = $_POST['password'];		
	    $sql = "SELECT id,type,email,name, password,status FROM user WHERE email = '$email' AND password = '$password'";
		$result = mysqli_query($conn,$sql) or die(mysqli_error($conn));
		$counts     = mysqli_num_rows($result);       
        if($counts > 0){
    	    $rows     = mysqli_fetch_assoc($result);
            if($rows['status']==0){
                $_SESSION['msg'] = 'Your account is suspended';
                @mysqli_close($conn); // Closing Connection
                header('Location: index.php'); // Redirecting To Home Page
                exit;
            }else{
                $_SESSION['user_id'] = $rows['id'];
                $_SESSION['type'] = $rows['type'];
                $_SESSION['login_user'] = $email;
                $_SESSION['user_name'] = $rows['name'];
                header("Location:campaign.php");
                exit;
            }
    	}else{
            $_SESSION['msg'] = 'Wrong user name or password';
            @mysqli_close($conn); // Closing Connection
            header('Location: index.php'); // Redirecting To Home Page
            exit;
        }
    }
}
?>