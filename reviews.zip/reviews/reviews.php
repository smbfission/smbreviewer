<?php
//@header('Access-Control-Allow-Origin: *');
include_once("database.php");
$_REQUEST['id'] = base64_decode($_REQUEST['id']);

$sql = "SELECT * FROM `campaigns` where id = '".@$_REQUEST['id']."'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();

$sql_set = "select * from user where id = '".$row['user_id']."'";
$exe_set = @mysqli_query($conn,$sql_set);
$settings = @mysqli_fetch_assoc($exe_set);
$access_token = @$settings['access_token'];

if(isset($_SERVER["HTTPS"])){
    $protocol = "https://";
}else{
    $protocol = "http://";
}
$currentPageUrl = $protocol.$_SERVER['SERVER_NAME'].$_SERVER['REQUEST_URI'];

$og_image = getServerURL()."uploads/".$row['meta_picture'];

if(!isset($_REQUEST['src'])){
?>
<html>
    <head>
    
        <!--Meta Information-->
        
        <title><?php echo $row['meta_title']; ?></title>
        
        <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">  
        
        <meta name="description" content="<?php echo $row['meta_description']; ?>" />
                
        <meta property="og:url" content="<?php echo $currentPageUrl; ?>" />
        <meta property="og:title" content="<?php echo $row['meta_title']; ?>" />
        <meta property="og:description" content="<?php echo $row['meta_description']; ?>" />
        
        <meta property="og:image" content="<?php echo $og_image; ?>" />
        <meta property="og:image:url" content="<?php echo $og_image; ?>" />
        <meta property="og:image:secure_url" content="<?php echo $og_image; ?>" />
        
        <meta property="og:type" content="website" />
        
        <meta name="twitter:title" content="<?php echo $row['meta_title']; ?>" />
        <meta name="twitter:card" content="photo" />
        <meta name="twitter:image" content="<?php echo $og_image; ?>" />
        <link rel="canonical" href="<?php echo $currentPageUrl; ?>" />
        <!--Meta Information-->

        <!-- App css -->
        <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
        
        
        <!-- jQuery  -->
        <script src="assets/vendor/jquery/jquery.js"></script>
        <script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
        
        <script src="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.js"></script>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/rateYo/2.3.2/jquery.rateyo.min.css">

    </head>
    <body>
    
    

<?php
}
?>

<script>

function addRating(){
    $("#reviews .user-rating").each(function(){
        var score = $(this).html();
        var color = $("#rating_color").val();
        $(this).html("");
        $(this).rateYo({
            rating : score,
            starWidth: "15px",
            ratedFill: color,
            readOnly: true,
        })
    })
}

</script>

<style>
body{
    background:none;
}
.card-box{
    margin:0;
}
.jq-ry-container{
    padding:0 !important;
}
.carousel-caption{
    padding:30px 55px;
    position: unset;
    text-shadow:none;
    color:inherit;
}
.carousel-inner > .item{
    padding-top:10px;
}
.card-box{
    box-shadow:none;
}
.thumbnail{
    padding: 10px 10px 0px 10px;
}
.checkbox {
    padding: 0;
}
</style>




                                <div class="card-box table-responsive">
                                   
                                    <?php
                                    
                                    if(@$row['is_facebook']==1){
                                        $url="https://graph.facebook.com/$row[fb_page]/ratings?access_token=$row[page_token]&limit=100&fields=created_time,has_rating,has_review,open_graph_story,rating,review_text,reviewer";
                                        $facebook_json = post_fb($url,"get");
                                        $facebook_data = json_decode($facebook_json,true);
                                    }
                                    
                                    if(@$row['is_google']==1){
                                        $url="https://maps.googleapis.com/maps/api/place/details/json?placeid=$row[place_id]&fields=name,rating,formatted_phone_number,reviews&key=".@$settings['google_key'];
                                        $google_json = post_fb($url,"get");
                                        $google_data = json_decode($google_json,true);
                                    }
                                    
                                    if(@$row['is_yelp']==1){
                                        $url="https://api.yelp.com/v3/businesses/$row[yelp_business_id]/reviews";
                                        $yelp_json = post_fb($url,"get","",@$settings['yelp_api_key']);
                                        $yelp_data = json_decode($yelp_json,true);
                                    }
                                    
                                    if(@$row['is_custom']==1){
                                        
                                        $url=getServerURL()."/review_api.php?uid=$row[user_id]";//.$_SESSION['user_id'];
                                        $custom_json=post_fb($url,"get"); 
                                        $custom_data = json_decode($custom_json,true);
                                    }
        							?>
                                    
                                    <style>
                                    .r_dp{
                                        display:<?php if($row['display_dp']=="0"){ echo "none"; } ?>;
                                    }
                                    .r_name{
                                        color:<?php echo $row['name_color']; ?>;
                                    }
                                    .r_rating{
                                        color:<?php echo $row['rating_color']; ?>;
                                        display:<?php if($row['display_rating']=="0"){ echo "none"; } ?>;
                                    }
                                    .r_date{
                                        color:<?php echo $row['date_color']; ?>;
                                        display:<?php if($row['display_date']=="0"){ echo "none"; } ?>;
                                    }
                                    .r_review{
                                        color:<?php echo $row['review_color']; ?>; 
                                        font-size:<?php echo $row['font_size']; ?>;
                                        font-family:<?php echo $row['font_family']; ?>;
                                        display:<?php if($row['display_review']=="0"){ echo "none"; } ?>;
                                    }
                                    .thumbnail{
                                        background:<?php echo $row['widget_bg_color']; ?>;
                                        box-shadow:0 2px 5px <?php echo $row['widget_box_shadow']; ?>, 0 2px 10px rgba(0, 0, 0, 0);
                                    } 
                                    .carousel-inner .item{
                                        background:<?php echo $row['widget_bg_color']; ?>;
                                    }
                                    
                                    </style>
                                    
                                    
                                    <input id="rating_color" type="hidden" value="<?php echo $row['rating_color']; ?>" />
                                            
									
                                    
                                    <div class="">
										<div class="col-md-12">
											<div class="form-group" id="reviews">
                                                <?php
                                                if(@$row['is_google']==1 || @$row['is_facebook']==1 || @$row['is_yelp']==1 || @$row['is_custom']==1){
                                                    if(@$row['style']=="slide"){
                                                        ?>
                                                        <div id="carousel-example-captions" data-ride="carousel" class="carousel slide">
                                                            <div role="listbox" class="carousel-inner">
                                                        <?php
                                                    }else{
                                                        ?>
                                                        <ul class="media-list">
                                                        <?php    
                                                    }
                                                }
                                                
                                                $i=1;
                                                if(@$row['is_google']==1){
                                                    if(isset($google_data['result']['reviews'])){
                                                        //$i=1;
                                                        foreach($google_data['result']['reviews'] as $reviews){
                                                            
                                                            $action_url = $reviews['author_url'];
                                                            $picture_url = $reviews['profile_photo_url'];
                                                            $author_name = $reviews['author_name'];
                                                            $rating = $reviews['rating'];
                                                            $date = $reviews['relative_time_description'];
                                                            $review = $reviews['text'];
                                                            
                                                            if(@$row['style']=="list"){
                                                                ?>
                                                                <li class="media thumbnail">
                                                                    <a class="pull-left" href="<?php echo $action_url; ?>" target="_blank">
                                                                        <img class="media-object img-circle  r_dp" style="width:50px; height:50px;"
                                                                             src="<?php echo $picture_url; ?>" alt=""/>
                                                                    </a>
                                                                    <div class="media-body">
                                                                        <h5 class="media-heading"><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h5>
                                                                        <h6 class="r_date"><?php echo $date; ?></h6>
                                                                        <p class="r_review" align="justify"><?php echo $review; ?></p>
                                                                    </div>
                                                                </li>
                                                                <?php
                                                            }
                                                            else if(@$row['style']=="grid"){
                                                                ?>
                                                                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 ">
                                                                    <div class="thumbnail">
                                                                        <img src="<?php echo $picture_url; ?>" class="img-responsive r_dp" alt=""/>
                                                                        <div class="caption" align="center">
                                                                            <h3><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h3>
                                                                            <h6 class="r_date"><?php echo $date; ?></h6>
                                                                            <p class="r_review" align="justify"><?php echo $review; ?></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <?php
                                                            }
                                                            else if(@$row['style']=="slide"){
                                                                ?>
                                                                <div class="item <?php if($i==1){ echo "active"; } ?>" align="center">
                            										<div class="row">
                                                                        <div class="col-md-12">
                                                                            <img src="<?php echo $picture_url; ?>" class="img-responsive r_dp" alt=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-12">
                                    										<div class="carousel-caption" align="center">
                                    											<h3 class="font-600 r_name" align="center"><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h3>
                                    											<h6 class="r_date"><?php echo $date; ?></h6>
                                                                                <p class="r_review" align="center"><?php echo $review; ?></p>
                                    										</div>
                                                                        </div>
                                                                    </div>
                            									</div>
                                                                <?php
                                                            }
                                                            $i++;
                                                        }
                                                    }  
                                                }
                                                
                                                if(@$row['is_facebook']==1){
                                                    if(isset($facebook_data['data'])){
                                                        //$i=1;
                                                        foreach($facebook_data['data'] as $reviews){
                                                            
                                                            $action_url = $reviews['open_graph_story']['id'];
                                                            $picture_url = "https://graph.facebook.com/".$reviews['profile_photo_url']."/picture?type=large";
                                                            $author_name = $reviews['reviewer']['name'];
                                                            $rating = $reviews['rating'];
                                                            $date = $reviews['created_time'];
                                                            $review = $reviews['review_text'];
                                                            
                                                            if(@$row['style']=="list"){
                                                                ?>
                                                                <li class="media thumbnail">
                                                                    <a class="pull-left" href="<?php echo $action_url; ?>" target="_blank">
                                                                        <img class="media-object img-circle  r_dp" style="width:50px; height:50px;"
                                                                             src="<?php echo $picture_url; ?>" alt=""/>
                                                                    </a>
                                                                    <div class="media-body">
                                                                        <h5 class="media-heading"><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h5>
                                                                        <h6 class="r_date"><?php echo $date; ?></h6>
                                                                        <p class="r_review" align="justify"><?php echo $review; ?></p>
                                                                    </div>
                                                                </li>
                                                                <?php
                                                            }
                                                            else if(@$row['style']=="grid"){
                                                                ?>
                                                                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 ">
                                                                    <div class="thumbnail">
                                                                        <img src="<?php echo $picture_url; ?>" class="img-responsive r_dp" alt=""/>
                                                                        <div class="caption" align="center">
                                                                            <h3><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h3>
                                                                            <h6 class="r_date"><?php echo $date; ?></h6>
                                                                            <p class="r_review" align="justify"><?php echo $review; ?></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <?php
                                                            }
                                                            else if(@$row['style']=="slide"){
                                                                ?>
                                                                <div class="item <?php if($i==1){ echo "active"; } ?>" align="center">
                            										<div class="row">
                                                                        <div class="col-md-12">
                                                                            <img src="<?php echo $picture_url; ?>" class="img-responsive r_dp" alt=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-12">
                                    										<div class="carousel-caption" align="center">
                                    											<h3 class="font-600 r_name" align="center"><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h3>
                                    											<h6 class="r_date"><?php echo $date; ?></h6>
                                                                                <p class="r_review" align="center"><?php echo $review; ?></p>
                                    										</div>
                                                                        </div>
                                                                    </div>
                            									</div>
                                                                <?php
                                                            }
                                                            $i++;
                                                        }
                                                    }   
                                                }
                                                
                                                if(@$row['is_custom']==1){
                                                    if(isset($custom_data['data'])){
                                                        //$i=1;
                                                        foreach($custom_data['data'] as $reviews){
                                                            
                                                            $action_url = "#";
                                                            $picture_url = $reviews['photo'];
                                                            $author_name = $reviews['name'];
                                                            $rating = $reviews['rating'];
                                                            $date = $reviews['date'];
                                                            $review = $reviews['review'];
                                                            
                                                            if(@$row['style']=="list"){
                                                                ?>
                                                                <li class="media thumbnail">
                                                                    <a class="pull-left" href="<?php echo $action_url; ?>" target="_blank">
                                                                        <img class="media-object img-circle  r_dp" style="width:50px; height:50px;"
                                                                             src="<?php echo $picture_url; ?>" alt=""/>
                                                                    </a>
                                                                    <div class="media-body">
                                                                        <h5 class="media-heading"><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h5>
                                                                        <h6 class="r_date"><?php echo $date; ?></h6>
                                                                        <p class="r_review" align="justify"><?php echo $review; ?></p>
                                                                    </div>
                                                                </li>
                                                                <?php
                                                            }
                                                            else if(@$row['style']=="grid"){
                                                                ?>
                                                                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 ">
                                                                    <div class="thumbnail">
                                                                        <img src="<?php echo $picture_url; ?>" class="img-responsive r_dp" alt=""/>
                                                                        <div class="caption" align="center">
                                                                            <h3><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h3>
                                                                            <h6 class="r_date"><?php echo $date; ?></h6>
                                                                            <p class="r_review" align="justify"><?php echo $review; ?></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <?php
                                                            }
                                                            else if(@$row['style']=="slide"){
                                                                ?>
                                                                <div class="item <?php if($i==1){ echo "active"; } ?>" align="center">
                            										<div class="row">
                                                                        <div class="col-md-12">
                                                                            <img src="<?php echo $picture_url; ?>" class="img-responsive r_dp" alt=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-12">
                                    										<div class="carousel-caption" align="center">
                                    											<h3 class="font-600 r_name" align="center"><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h3>
                                    											<h6 class="r_date"><?php echo $date; ?></h6>
                                                                                <p class="r_review" align="center"><?php echo $review; ?></p>
                                    										</div>
                                                                        </div>
                                                                    </div>
                            									</div>
                                                                <?php
                                                            }
                                                            $i++;
                                                        }
                                                    }   
                                                }
                                                
                                                if(@$row['is_yelp']==1){
                                                    
                                                    if(isset($yelp_data['reviews'])){
                                                        foreach($yelp_data['reviews'] as $reviews){
                                                            
                                                            $action_url = $reviews['url'];
                                                            $picture_url = $reviews['user']['image_url'];
                                                            $author_name = $reviews['user']['name'];
                                                            $rating = $reviews['rating'];
                                                            $date = $reviews['time_created'];
                                                            $review = $reviews['text'];
                                                            
                                                            if(@$row['style']=="list"){
                                                                ?>
                                                                <li class="media thumbnail">
                                                                    <a class="pull-left" href="<?php echo $action_url; ?>" target="_blank">
                                                                        <img class="media-object img-circle  r_dp" style="width:50px; height:50px;"
                                                                             src="<?php echo $picture_url; ?>" alt=""/>
                                                                    </a>
                                                                    <div class="media-body">
                                                                        <h5 class="media-heading"><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h5>
                                                                        <h6 class="r_date"><?php echo $date; ?></h6>
                                                                        <p class="r_review" align="justify"><?php echo $review; ?></p>
                                                                    </div>
                                                                </li>
                                                                <?php
                                                            }
                                                            else if(@$row['style']=="grid"){
                                                                ?>
                                                                <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12 ">
                                                                    <div class="thumbnail">
                                                                        <img src="<?php echo $picture_url; ?>" class="img-responsive r_dp" alt=""/>
                                                                        <div class="caption" align="center">
                                                                            <h3><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h3>
                                                                            <h6 class="r_date"><?php echo $date; ?></h6>
                                                                            <p class="r_review" align="justify"><?php echo $review; ?></p>
                                                                        </div>
                                                                    </div>
                                                                </div>
                                                                <?php
                                                            }
                                                            else if(@$row['style']=="slide"){
                                                                ?>
                                                                <div class="item <?php if($i==1){ echo "active"; } ?>" align="center">
                            										<div class="row">
                                                                        <div class="col-md-12">
                                                                            <img src="<?php echo $picture_url; ?>" class="img-responsive r_dp" alt=""/>
                                                                        </div>
                                                                    </div>
                                                                    <div class="row">
                                                                        <div class="col-md-12">
                                    										<div class="carousel-caption" align="center">
                                    											<h3 class="font-600 r_name" align="center"><a href="<?php echo $action_url; ?>" target="_blank" class="r_name"><?php echo $author_name; ?></a> <span class="user-rating r_rating"><?php echo $rating; ?></span></h3>
                                    											<h6 class="r_date"><?php echo $date; ?></h6>
                                                                                <p class="r_review" align="center"><?php echo $review; ?></p>
                                    										</div>
                                                                        </div>
                                                                    </div>
                            									</div>
                                                                <?php
                                                            }
                                                            $i++;
                                                        }
                                                    }   
                                                }
                                                
                                                
                                                
                                                if(@$row['is_google']==1 || @$row['is_facebook']==1 || @$row['is_yelp']==1 || @$row['is_custom']==1){
                                                    if(@$row['style']=="slide"){
                                                        ?>
                                                            </div>
                                                            <a href="#carousel-example-captions" role="button" data-slide="prev" class="left carousel-control"> 
                                                                <span aria-hidden="true" class="fa fa-angle-left"></span>
                                                                <span class="sr-only">Previous</span> 
                                                            </a>
                                                            <a href="#carousel-example-captions" role="button" data-slide="next" class="right carousel-control">
                                                                <span aria-hidden="true" class="fa fa-angle-right"></span>
                                                                <span class="sr-only">Next</span>
                                                            </a>
                                                        </div>
                                                        <?php
                                                    }else{
                                                        ?>
                                                        </ul>
                                                        <?php    
                                                    }
                                                    
                                                    if(!isset($_REQUEST['src'])){
                                                    ?>
                                                        <script>addRating()</script>
                                                    <?php
                                                    }
                                                    
                                                }
                                                
                                                
                                                
                                                ?>
                                            
                                            
                                            </div>
										</div>
									</div>
                                   
                                </div>
<?php
if(!isset($_REQUEST['src'])){
?>                          
        </body>
    </html>
<?php
}
?>

<?php
function post_fb($url,$method,$body="",$apiKey=""){
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url );
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 100);
    curl_setopt($ch, CURLOPT_TIMEOUT, 100);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    if($apiKey!=""){
        $headr[] = 'Authorization: Bearer '.$apiKey;
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headr);
    }
    if($method == "post"){
        curl_setopt($ch, CURLOPT_POST, true );
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    else{
        curl_setopt($ch, CURLOPT_HTTPGET, true );   
    }   
    return curl_exec($ch);
}

function getServerURL()
{
    $serverName = $_SERVER['SERVER_NAME'];
    $filePath = $_SERVER['REQUEST_URI'];
    $withInstall = substr($filePath,0,strrpos($filePath,'/')+1);
    $serverPath = $serverName.$withInstall;
    $applicationPath = $serverPath;
    
    if(strpos($applicationPath,'http://www.')===false)
    {
    if(strpos($applicationPath,'www.')===false)
    $applicationPath = 'www.'.$applicationPath;
    if(strpos($applicationPath,'http://')===false)
    $applicationPath = 'http://'.$applicationPath;
    }
    
    if(isset($_SERVER["HTTPS"])){
        $protocol = "https://";
    }else{
        $protocol = "http://";
    }
    
    $applicationPath = str_replace("www.","",$applicationPath);
    $applicationPath = str_replace("http://",$protocol,$applicationPath);
    $applicationPath = str_replace("https://",$protocol,$applicationPath);
        
    return $applicationPath;
}
?>