<?php
@session_start();
if ($_SESSION['login_user'] == ""){
    $_SESSION['msg'] = "Please login 1st to access the page.";
    header('Location: index.php');
}

$directoryURI = $_SERVER['REQUEST_URI'];
$path = parse_url($directoryURI, PHP_URL_PATH);

$components = explode('/', $path);

$first_part = @$components[count($components)-1];
include_once("database.php");
?>
<!doctype html>
<html class="fixed">
	<head>

		<!-- Basic -->
		<meta charset="UTF-8">
        
        <!-- App favicon -->
        <link rel="shortcut icon" href="assets/images/favicon.ico">
        <!-- App title -->
        <title> <?php echo ucwords(str_replace(array(".php","_")," ",$first_part)); ?> | Get My Reviews</title>
        
		<meta name="keywords" content="HTML5 Admin Template" />
		<meta name="description" content="Porto Admin - Responsive HTML5 Template">
		<meta name="author" content="okler.net">
        
        

		<!-- Mobile Metas -->
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />

		<!-- Web Fonts  -->
		<link href="http://fonts.googleapis.com/css?family=Open+Sans:300,400,600,700,800|Shadows+Into+Light" rel="stylesheet" type="text/css">

		<!-- Vendor CSS -->
		<link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.css" />
		<link rel="stylesheet" href="assets/vendor/font-awesome/css/font-awesome.css" />
		<link rel="stylesheet" href="assets/vendor/magnific-popup/magnific-popup.css" />
		<link rel="stylesheet" href="assets/vendor/bootstrap-datepicker/css/datepicker3.css" />

		<!-- Specific Page Vendor CSS -->
		<link rel="stylesheet" href="assets/vendor/select2/select2.css" />
		<link rel="stylesheet" href="assets/vendor/jquery-datatables-bs3/assets/css/datatables.css" />

		<!-- Theme CSS -->
		<link rel="stylesheet" href="assets/stylesheets/theme.css" />

		<!-- Skin CSS -->
		<link rel="stylesheet" href="assets/stylesheets/skins/default.css" />

		<!-- Theme Custom CSS -->
		<link rel="stylesheet" href="assets/stylesheets/theme-custom.css">

		<!-- Head Libs -->
		<script src="assets/vendor/modernizr/modernizr.js"></script>

	</head>
	<body>
		<section class="body">
        
        
            <?php        
            function getUpdateDetails($version){
            	$url = "https://updates.ranksol.com/app_updates/reviews_updates/update.php?ver=".$version;
            	$ch = curl_init();//Here is the file we are downloading, replace spaces with %20
            	curl_setopt($ch, CURLOPT_URL, $url);
            	curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 100);
            	curl_setopt($ch, CURLOPT_TIMEOUT, 100);
            	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
            	curl_setopt($ch, CURLOPT_POST, true );
            	curl_setopt($ch, CURLOPT_POSTFIELDS, @$arr); 
            	$data = curl_exec($ch);//get curl response
            	curl_close($ch);
            	//print_r($data);
            	return $data;
            }
            
            
            $sql_ver = "select version from settings";
            $exe_ver = mysqli_query($conn,$sql_ver);
            $row_ver = mysqli_fetch_assoc($exe_ver);
            
            
            $version = $row_ver['version']; 
            $result = getUpdateDetails($version);
            $result = json_decode($result); 
            $latestVersion = @$result->version;
            $Error = @$result->error;
            if($Error != "invalid")
            {
            	$up_display  = "display:inline;";
            }
            else
            {
            	$up_display  = "display:none;";
            }
    		//$up_display  = "display:inline;";
            $updates = @$result->updates;
            ?>
            
            <div class="modal fade bs-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" style="display: none;" id="pop-up">
            <div class="modal-dialog" style="margin-top: 160px;">
                <div class="modal-content">
                  <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Latest Version <?=$latestVersion;?></h4>
                  </div>
                  <div class="modal-body" style="height:251px; overflow-y:auto;">
            		<?php
                    $length = count($updates);
                    $_SESSION['update_list'] = $updates;
                    $a=1;
                    ?>
                    <table class="table table-hover table-bordered" style="font-size:11px;">
                        <thead>
                        	<tr>
                                <td colspan="2"> New Features / Fixed Issues</td>
                            </tr>
                        </thead>
                        <tbody>
            				<?php
                            for($i=0; $i<$length; $i++)
                            {?>
            					<tr>
                                    <td><?=$a?></td>
                                    <td><?php echo $updates[$i];?> </td>
                                </tr>
                            <?php
            				$a++;
            				}
                            ?>
                        </tbody>
                    </table>
                  </div>
                  <div class="modal-footer">
                    <form action="up_v6.php" role="form">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-success">Update</button>
                    </form>
                  </div>
                </div><!-- /.modal-content -->
              </div><!-- /.modal-dialog -->
            </div><!-- /.modal -->

			<!-- start: header -->
			<header class="header">
				<div class="logo-container">
					<a href="../" class="logo" style="font-size:25px;">
						<!--<img src="assets/images/logo.png" height="35" alt="Porto Admin" />-->
                        Get My Reviews
					</a>
					<div class="visible-xs toggle-sidebar-left" data-toggle-class="sidebar-left-opened" data-target="html" data-fire-event="sidebar-left-opened">
						<i class="fa fa-bars" aria-label="Toggle sidebar"></i>
					</div>
				</div>
			
				<!-- start: search & user box -->
				<div class="header-right">
			
					<span class="separator"></span>
			
					<div id="userbox" class="userbox">
						<a href="#" data-toggle="dropdown">
							<div class="profile-info" data-lock-name="John Doe" data-lock-email="johndoe@okler.com">
								<span class="name"><?php echo @$_SESSION['user_name']; ?></span>
								<span class="role" style="display: none;">administrator</span>
							</div>
			
							<i class="fa custom-caret"></i>
						</a>
			
						<div class="dropdown-menu">
							<ul class="list-unstyled">
								<li class="divider"></li>
								<li>
									<a role="menuitem" tabindex="-1" href="profile.php"><i class="fa fa-user"></i> My Profile</a>
								</li>
								<li>
									<a role="menuitem" tabindex="-1" href="logout.php"><i class="fa fa-power-off"></i> Logout</a>
								</li>
							</ul>
						</div>
					</div>
				</div>
				<!-- end: search & user box -->
			</header>
			<!-- end: header -->

			<div class="inner-wrapper">