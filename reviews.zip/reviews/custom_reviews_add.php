<?php
include_once("header.php");
include_once("sidebar.php");
?>
<link rel="stylesheet" href="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.css" />
          <section role="main" class="content-body">
					<header class="page-header">
						<h2>Custom Reviews</h2>
					
						<div class="right-wrapper pull-right" style="display:none;">
							<ol class="breadcrumbs">
								<li>
									<a href="index.html">
										<i class="fa fa-home"></i>
									</a>
								</li>
								<li><span>Tables</span></li>
								<li><span>Advanced</span></li>
							</ol>
					
							<a class="sidebar-right-toggle" data-open="sidebar-right"><i class="fa fa-chevron-left"></i></a>
						</div>
					</header>
                    
                    <div class="row">
						<div class="col-lg-12">
							<section class="panel">
								<div class="panel-body">
                                
                                    <div class="row">
                                        <div class="col-sm-12">
            								<h2 class="h2 mt-none mb-sm text-dark text-bold">
                                                Create Custom Reviews
                                            </h2>
            								<p class="text-muted font-13 m-b-15">                                            
                                                <!-- Description Goes Here <br /> -->
                                                 Create your own Custom Reviews &nbsp;
                                            </p>
            							</div>
                                        
                                        
                                        <?php
                                        if(isset($_SESSION['msg']) && $_SESSION['msg']!=""){
                                            ?>
                                            <div class="col-sm-12">
                                                <div class="alert alert-info"><?php echo $_SESSION['msg']; ?></div>
                                            </div>
                                            <?php
                                            unset($_SESSION['msg']);
                                        }
                                        ?>
                                    </div>
                                
                                    <?php  
                                    $sql = "select * from custom_reviews where id='".@$_REQUEST['id']."'";
                                	$res = mysqli_query($conn,$sql);
                             	    $row = mysqli_fetch_assoc($res);
                                    ?>
                                
									<!-- <form class="form-horizontal form-bordered" method="get"> -->
                                    <form action="action.php?action=custom_reviews" class="form-horizontal form-bordered" method="post" enctype="multipart/form-data">
									   
                                        <?php
                                        if(@$row['photo']!=""){
                                            $photo_required="";
                                        }else{
                                            $photo_required="required";
                                        }
                                       ?>
                                       
                                        <div class="form-group">
											<label class="col-md-3 control-label">Auther Picture</label>
											<div class="col-md-6">
												<div class="fileupload fileupload-new" data-provides="fileupload">
													<div class="input-append">
														<div class="uneditable-input">
															<i class="fa fa-file fileupload-exists"></i>
															<span class="fileupload-preview"></span>
														</div>
														<span class="btn btn-default btn-file">
															<span class="fileupload-exists">Change</span>
															<span class="fileupload-new">Select file</span>
															<input name="photo" type="file" <?php echo ""; ?> />
                                                            <input name="hidden_photo" type="hidden" value="<?php echo $row['photo']; ?>" />
														</span>
														<a href="#" class="btn btn-default fileupload-exists" data-dismiss="fileupload">Remove</a>
													</div>
												</div>
                                                 <?php 
                                                 if(@$row['photo']!=""){
                                                    ?>
                                                    <img src="uploads/<?php echo @$row['photo']; ?>" class="img-thumbnail" style="max-height: 100px;" />
                                                    <br /><br />
                                                    <?php
                                                 }
                                                 ?>
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Auther Name</label>
											<div class="col-md-6">
                                                <input class="form-control" name="name" value="<?php echo @$row['name'] ?>" type="text" required="" placeholder="i.e: Jason Mike">
											</div>
										</div>
					
                                        <?php
                                        if(!isset($row['rating'])){
                                            $row['rating']=4.5;
                                        }
                                        ?>
                                        <div class="form-group">
											<label class="col-md-3 control-label">Rating</label>
											<div class="col-md-6">
												<div data-plugin-spinner data-plugin-options='{ "value":<?php echo @$row['rating'] ?>, "step": 0.1, "min": 1, "max": 5 }'>
													<div class="input-group" style="width:150px;">
														<input type="text" name="rating" class="spinner-input form-control" maxlength="5" readonly>
														<div class="spinner-buttons input-group-btn">
															<button type="button" class="btn btn-default spinner-up">
																<i class="fa fa-angle-up"></i>
															</button>
															<button type="button" class="btn btn-default spinner-down">
																<i class="fa fa-angle-down"></i>
															</button>
														</div>
													</div>
												</div>
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDefault">Review</label>
											<div class="col-md-6">
												<textarea class="form-control" name="review" placeholder="Write your review here" required=""><?php echo @$row['review'] ?></textarea>
											</div>
										</div>
                                        <?php
                                        if(!isset($row['date'])){
                                            $row['date']=date("Y-m-d");
                                        }
                                        ?>
                                        <div class="form-group">
											<label class="col-md-3 control-label">Review Date</label>
											<div class="col-md-6">
												<div class="input-group">
													<span class="input-group-addon">
														<i class="fa fa-calendar"></i>
													</span>
													<input type="text" name="date" value="<?php echo date("m/d/Y",strtotime($row['date'])); ?>" data-plugin-datepicker class="form-control" required="">
												</div>
											</div>
										</div>
                                        
                                        <div class="form-group">
											<label class="col-md-3 control-label" for="inputDisabled"></label>
											<div class="col-md-6">
												<input name="id" type="hidden" value="<?php echo @$_REQUEST['id']; ?>" />
                                                <button type="submit" name="submit" value="submit"  class="btn  btn-fill btn-success"><span class="ace-icon fa fa-save bigger-120"></span> Save</button>
											</div>
										</div>
                                    </form>
								</div>
							</section>
                        </div>
                    </div>
                    <!-- end: page -->
				</section>
			</div>
            
            </section>

		<!-- Vendor -->
		<script src="assets/vendor/jquery/jquery.js"></script>
		<script src="assets/vendor/jquery-browser-mobile/jquery.browser.mobile.js"></script>
		<script src="assets/vendor/bootstrap/js/bootstrap.js"></script>
		<script src="assets/vendor/nanoscroller/nanoscroller.js"></script>
		<script src="assets/vendor/bootstrap-datepicker/js/bootstrap-datepicker.js"></script>
		<script src="assets/vendor/magnific-popup/magnific-popup.js"></script>
		<script src="assets/vendor/jquery-placeholder/jquery.placeholder.js"></script>
		
		<!-- Specific Page Vendor -->
		<script src="assets/vendor/jquery-autosize/jquery.autosize.js"></script>
		<script src="assets/vendor/bootstrap-fileupload/bootstrap-fileupload.min.js"></script>
        <script src="assets/vendor/fuelux/js/spinner.js"></script>
		
		<!-- Theme Base, Components and Settings -->
		<script src="assets/javascripts/theme.js"></script>
		
		<!-- Theme Custom -->
		<script src="assets/javascripts/theme.custom.js"></script>
		
		<!-- Theme Initialization Files -->
		<script src="assets/javascripts/theme.init.js"></script>

	</body>
</html>